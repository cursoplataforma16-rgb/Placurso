/* ANNAN — injeta o contexto operacional nas chamadas do agente quando esta interface estiver activa. */
(function(){
  'use strict';
  function instalar(){
    if(window.__ANNAN_CONTEXTO_INJETADO || !window.ANNAN_CONTEXTO_OPERACIONAL || typeof sb==='undefined' || !sb.functions || typeof sb.functions.invoke!=='function') return false;
    const original=sb.functions.invoke.bind(sb.functions);
    sb.functions.invoke=async function(name,options){
      if(name==='annan-agente' && options && options.body){
        const body=options.body;
        options=Object.assign({},options,{body:Object.assign({},body,{contexto_operacional:window.ANNAN_CONTEXTO_OPERACIONAL,contexto_versao:window.ANNAN_CONTEXTO_OPERACIONAL.versao})});
      }
      return original(name,options);
    };
    window.__ANNAN_CONTEXTO_INJETADO=true;
    return true;
  }
  if(!instalar()){
    let tentativas=0;
    const timer=setInterval(function(){tentativas++;if(instalar()||tentativas>=60)clearInterval(timer)},250);
  }
})();
