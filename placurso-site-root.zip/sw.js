// Service worker da Dionuel — permite abrir o site e ver os últimos
// dados carregados mesmo sem internet. Criar/editar/apagar continua a
// exigir rede (não há fila de escrita offline, de propósito: os dados só
// devem "entrar no sistema", visíveis para todos, quando há ligação).
//
// Suba este ficheiro por ficheiro, e o manifest.json, para a MESMA pasta
// onde está o index.html no servidor (ex.: Netlify) — senão o navegador
// não os encontra.

const CACHE_VERSAO = 'dionuel-v160-autonomia';
const FICHEIROS_ESSENCIAIS = [
  './', './index.html', './manifest.json', './icon-192.png', './icon-512.png', './logo-dionuel.webp',
  // Sem estes dois, o site fica preso ao abrir offline — são a biblioteca
  // do Supabase e o gerador de PDF, servidos pelo próprio domínio (não
  // pela CDN direta) para funcionar mesmo com VPNs que bloqueiam CDNs.
  './vendor/supabase-js.js', './vendor/jspdf.js',
  // Tipo de letra — sem isto, offline mostra uma fonte de reserva (não
  // trava o site, mas fica menos bonito na primeira visita sem rede).
  'https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600;9..144,700&family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap'
];

self.addEventListener('install', (evento) => {
  self.skipWaiting();
  evento.waitUntil(
    caches.open(CACHE_VERSAO).then((cache) => {
      // Cada ficheiro é guardado isoladamente — se um falhar (ex.: nome
      // diferente no servidor), não impede os outros de ficarem em cache.
      return Promise.all(
        FICHEIROS_ESSENCIAIS.map((f) => cache.add(f).catch(() => null))
      );
    })
  );
});

self.addEventListener('activate', (evento) => {
  self.clients.claim();
  evento.waitUntil(
    caches.keys().then((nomes) =>
      Promise.all(nomes.filter((n) => n !== CACHE_VERSAO).map((n) => caches.delete(n)))
    )
  );
});

self.addEventListener('fetch', (evento) => {
  const req = evento.request;

  // Nunca intercetar escritas (POST/PATCH/PUT/DELETE) — têm de ir
  // sempre à rede a sério, e falhar claramente se não houver ligação.
  if(req.method !== 'GET') return;

  const url = new URL(req.url);
  const ehSupabaseRest = url.hostname.endsWith('.supabase.co') && url.pathname.startsWith('/rest/');

  // Navegação (abrir/recarregar a página): tenta a rede primeiro, cai
  // para a cópia guardada em cache se estiver offline.
  if(req.mode === 'navigate'){
    evento.respondWith(
      fetch(req).catch(() => caches.match('./index.html').then((r) => r || caches.match('./')))
    );
    return;
  }

  // Leituras ao Supabase (GET): tenta a rede e guarda a resposta mais
  // recente; se falhar (sem rede), usa a última resposta guardada —
  // é assim que os dados "nunca se perdem" mesmo após meses offline.
  if(ehSupabaseRest){
    evento.respondWith(
      fetch(req)
        .then((resp) => {
          const copia = resp.clone();
          caches.open(CACHE_VERSAO).then((cache) => cache.put(req, copia));
          return resp;
        })
        .catch(() => caches.match(req))
    );
    return;
  }

  // Tudo o resto (fontes, scripts do CDN, etc.): cache primeiro, com a
  // rede como reserva — mais rápido e funciona offline depois da 1ª visita.
  evento.respondWith(
    caches.match(req).then((cached) => {
      if(cached) return cached;
      return fetch(req).then((resp) => {
        const copia = resp.clone();
        caches.open(CACHE_VERSAO).then((cache) => cache.put(req, copia));
        return resp;
      }).catch(() => cached);
    })
  );
});

// Avisos da Dionuel no telemóvel: o servidor só "acorda" o telemóvel; aqui vamos buscar
// o aviso mais recente deste cliente (com o token guardado quando ele se inscreveu).
self.addEventListener('push', (evento) => {
  evento.waitUntil((async () => {
    let aviso = { titulo: 'Dionuel', texto: 'Há novidades para si.', link: '/' };
    try {
      const c = await caches.open('dv-avisos'); const r = await c.match('/__avisos_token');
      const token = r ? await r.text() : '';
      if (token) {
        const resp = await fetch('https://oettkaytgkkbrjoaeiqu.supabase.co/functions/v1/avisos', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ acao: 'ultimo', token }) });
        if (resp.ok) aviso = await resp.json();
      }
    } catch (_e) {}
    const curso = aviso.empresa === 'infoprodutos';
    await self.registration.showNotification(aviso.titulo || (curso ? 'Plataforma Curso' : 'Dionuel'), { body: aviso.texto || '', icon: curso ? './curso-icon-192.png' : './icon-192.png', badge: curso ? './curso-icon-192.png' : './icon-192.png', data: { link: aviso.link || (curso ? '/cursos' : '/') }, tag: curso ? 'curso-aviso' : 'dionuel-aviso', renotify: true });
  })());
});
self.addEventListener('notificationclick', (evento) => {
  evento.notification.close();
  const link = (evento.notification.data && evento.notification.data.link) || '/';
  evento.waitUntil(self.clients.openWindow(link));
});
