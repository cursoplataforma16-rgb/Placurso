/* Página inicial simples da Plataforma Curso: um objectivo principal, três benefícios e um único combo publicado. */
async function renderHomeCursoSimples(){
  aplicarMarca(true);
  document.body.classList.add('modo-loja');
  document.title = 'Plataforma Curso — Aprenda ao seu ritmo';
  if(!document.getElementById('pchHomeCss')){
    var style = document.createElement('style');
    style.id = 'pchHomeCss';
    style.textContent = [
      '.pch-home{min-height:100vh;padding-bottom:92px;background:#FBF9F2;color:#14284B;font-family:Inter,system-ui,sans-serif}',
      '.pch-home *{box-sizing:border-box}',
      '.pch-header{max-width:1120px;margin:0 auto;padding:18px 22px;display:flex;align-items:center;justify-content:space-between;gap:16px}',
      '.pch-brand{display:flex;align-items:center;gap:11px;text-decoration:none;color:#14284B;min-width:0}',
      '.pch-brand img{width:46px;height:46px;object-fit:contain;border-radius:12px}',
      '.pch-brand strong{display:block;font-size:12px;letter-spacing:.11em;line-height:1.4}',
      '.pch-brand small{display:block;color:#1B8A83;font-size:11px;margin-top:3px;letter-spacing:0}',
      '.pch-header-link{display:inline-flex;align-items:center;justify-content:center;min-height:44px;padding:0 16px;border-radius:11px;text-decoration:none;background:#14284B;color:#fff;font-weight:700;font-size:14px}',
      '.pch-main{max-width:1120px;margin:0 auto;padding:6px 22px 24px}',
      '.pch-hero-compact{grid-template-columns:minmax(0,1fr);max-width:1000px;margin:0 auto;padding:clamp(18px,2.5vw,28px);gap:8px;border-radius:22px}',
      '.pch-hero-compact .pch-title{max-width:790px;font-size:clamp(30px,3.9vw,43px);line-height:1.03;margin-bottom:10px}',
      '.pch-hero-compact .pch-lead{max-width:760px;font-size:14px;line-height:1.45}',
      '.pch-hero-compact .pch-actions{margin-top:17px}',
      '.pch-hero-compact .pch-free-note{margin-top:8px}',
      '.pch-hero{position:relative;overflow:hidden;display:grid;grid-template-columns:minmax(0,1.3fr) minmax(240px,.7fr);gap:32px;align-items:center;padding:clamp(28px,5vw,58px);border-radius:28px;background:linear-gradient(125deg,#14284B 0%,#0D1B35 100%);color:#fff;box-shadow:0 20px 48px -30px rgba(20,40,75,.6)}',
      '.pch-hero:after{content:"";position:absolute;width:280px;height:280px;right:-100px;top:-145px;border:1px solid rgba(42,163,155,.4);border-radius:50%;box-shadow:0 0 0 34px rgba(42,163,155,.05),0 0 0 68px rgba(42,163,155,.04);pointer-events:none}',
      '.pch-kicker{font-size:11px;font-weight:800;letter-spacing:.16em;text-transform:uppercase;color:#71D3C9;margin:0 0 15px}',
      '.pch-title{font-size:clamp(34px,5.1vw,58px);line-height:1.04;letter-spacing:-.035em;max-width:680px;margin:0 0 18px;color:#fff}',
      '.pch-lead{font-size:clamp(15px,1.8vw,18px);line-height:1.65;color:rgba(255,255,255,.82);max-width:610px;margin:0}',
      '.pch-actions{display:flex;flex-wrap:wrap;gap:10px;margin-top:25px}',
      '.pch-primary{min-height:50px;padding:0 21px;border:0;border-radius:12px;background:#2AA39B;color:#062F35;font-size:15px;font-weight:800;cursor:pointer;box-shadow:0 10px 24px -14px rgba(42,163,155,.9)}',
      '.pch-primary:hover{background:#71D3C9}',
      '.pch-proof{position:relative;z-index:1;background:rgba(255,255,255,.075);border:1px solid rgba(255,255,255,.18);border-radius:20px;padding:23px}',
      '.pch-proof-title{font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:#71D3C9;font-weight:800;margin:0 0 15px}',
      '.pch-proof-row{display:flex;gap:11px;align-items:flex-start;margin:14px 0 0;color:rgba(255,255,255,.9);font-size:14px;line-height:1.45}',
      '.pch-check{display:inline-flex;flex:none;width:24px;height:24px;align-items:center;justify-content:center;border-radius:8px;background:rgba(42,163,155,.18);color:#71D3C9;font-weight:900}',
      '.pch-free-note{margin:14px 0 0;font-size:12px;color:rgba(255,255,255,.68)}',
      '.pch-benefits{padding:44px 0 8px}',
      '.pch-section-kicker{font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:#1B8A83;font-weight:800;margin:0 0 9px}',
      '.pch-h2{font-size:clamp(24px,3vw,34px);line-height:1.12;letter-spacing:-.025em;margin:0;color:#14284B}',
      '.pch-benefit-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px;margin-top:22px}',
      '.pch-benefit{background:#fff;border:1px solid rgba(20,40,75,.10);border-radius:18px;padding:22px;min-height:155px}',
      '.pch-benefit-num{display:inline-flex;align-items:center;justify-content:center;width:32px;height:32px;background:#E6F5F2;color:#117970;border-radius:10px;font-size:12px;font-weight:900;margin-bottom:16px}',
      '.pch-benefit h3{font-size:16px;line-height:1.3;margin:0 0 8px;color:#14284B}',
      '.pch-benefit p{font-size:13.5px;line-height:1.55;color:#55657C;margin:0}',
      '.pch-offer{margin-top:28px;border-radius:20px;padding:clamp(16px,3vw,24px);background:#EAF1EF;border:1px solid rgba(20,40,75,.09)}',
      '.pch-products{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;margin-top:16px}',
      '.pch-product{display:flex;flex-direction:column;align-items:flex-start;min-width:0;padding:12px;border-radius:14px;background:#fff;border:1px solid rgba(20,40,75,.10)}',
      '.pch-product img{width:46px;height:54px;object-fit:contain;align-self:center;margin:0 0 7px;border-radius:7px;background:#F5F6F2}',
      '.pch-product strong{font-size:12px;line-height:1.35;min-height:34px;overflow-wrap:anywhere}',
      '.pch-product-price{font-size:12px;font-weight:800;margin:8px 0;color:#14284B}',
      '.pch-product button{width:100%;min-height:38px;border:0;border-radius:9px;background:#14284B;color:#fff;font-weight:800;font-size:12px;cursor:pointer;margin-top:auto}',
      '.pch-product button:hover{background:#1B8A83}',
      '.pch-offer-divider{display:flex;align-items:center;gap:10px;margin:18px 0 10px;color:#55657C;font-size:12px;font-weight:700}',
      '.pch-offer-divider:before,.pch-offer-divider:after{content:"";height:1px;background:rgba(20,40,75,.13);flex:1}',
      '.pch-offer-top{display:flex;justify-content:space-between;align-items:flex-end;gap:20px;margin-bottom:20px}',
      '.pch-offer-top p{color:#55657C;font-size:14px;line-height:1.5;max-width:480px;margin:10px 0 0}',
      '.pch-combo-card{background:#fff;border:1px solid rgba(20,40,75,.12);border-radius:16px;padding:13px;box-shadow:0 12px 30px -24px rgba(20,40,75,.45)}',
      '.pch-combo-items{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}',
      '.pch-combo-item{min-width:0;display:flex;align-items:center;gap:8px;padding:9px;background:#FBF9F2;border-radius:11px}',
      '.pch-combo-item img{width:42px;height:48px;object-fit:contain;border-radius:6px;background:#EAF1EF;flex:none}',
      '.pch-combo-item small{display:block;font-size:9px;color:#1B8A83;font-weight:800;letter-spacing:.08em;margin-bottom:4px}',
      '.pch-combo-item strong{display:block;font-size:11.5px;line-height:1.3;overflow-wrap:anywhere}',
      '.pch-combo-fallback{display:flex;gap:14px;align-items:center;background:#FBF9F2;padding:14px;border-radius:14px}',
      '.pch-combo-fallback img{width:76px;height:88px;object-fit:cover;border-radius:8px;background:#EAF1EF}',
      '.pch-combo-fallback h3{margin:0 0 5px;font-size:17px}',
      '.pch-combo-fallback p{margin:0;font-size:13px;color:#55657C;line-height:1.5}',
      '.pch-buy-row{display:flex;justify-content:space-between;align-items:center;gap:12px;border-top:1px solid rgba(20,40,75,.10);padding-top:12px;margin-top:12px}',
      '.pch-price{font-size:19px;font-weight:900;color:#14284B}',
      '.pch-price-note{font-size:11px;font-weight:500;color:#55657C;margin-top:4px}',
      '.pch-buy{min-height:44px;padding:0 16px;border:0;border-radius:10px;background:#14284B;color:#fff;font-weight:800;cursor:pointer}',
      '.pch-buy:hover{background:#1B8A83}',
      '.pch-challenges{padding:34px 0 16px}',
      '.pch-challenge-card{margin-top:16px;background:#fff;border:1px solid rgba(20,40,75,.12);border-radius:18px;padding:clamp(16px,3vw,24px)}',
      '.pch-challenge-head{display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap;margin-bottom:14px}',
      '.pch-tag{font-size:10px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:#137C73;background:#E6F5F2;padding:6px 9px;border-radius:999px}',
      '.pch-question{font-size:clamp(18px,2.4vw,23px);line-height:1.35;margin:0 0 15px;color:#14284B}',
      '.pch-choices{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px}',
      '.pch-choice{min-height:46px;text-align:left;padding:11px 13px;border:1px solid rgba(20,40,75,.17);border-radius:11px;background:#FBF9F2;color:#14284B;font-weight:650;cursor:pointer}',
      '.pch-choice:hover{border-color:#2AA39B}',
      '.pch-choice.selecionada{border:2px solid #1B8A83;background:#E6F5F2;padding:10px 12px}',
      '.pch-choice.certa{border-color:#18855C;background:#E6F6ED}',
      '.pch-choice.errada{border-color:#BC5757;background:#FFF0EF}',
      '.pch-feedback{margin:14px 0 0;padding:13px;border-radius:12px;background:#EFF5F8;color:#263B53;font-size:13.5px;line-height:1.55}',
      '.pch-challenge-actions{display:flex;gap:9px;flex-wrap:wrap;margin-top:14px}',
      '.pch-challenge-actions button{min-height:44px;padding:0 16px;border:0;border-radius:10px;background:#14284B;color:#fff;font-weight:800;cursor:pointer}',
      '.pch-challenge-actions button:disabled{opacity:.4;cursor:not-allowed}',
      '.pch-after3{margin-top:16px;background:#E6F5F2;border:1px solid rgba(27,138,131,.2);border-radius:15px;padding:16px}',
      '.pch-after3 h3{font-size:16px;margin:0 0 6px}',
      '.pch-after3 p{font-size:13px;line-height:1.5;color:#44556B;margin:0 0 12px}',
      '.pch-extra-actions{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}',
      '.pch-extra-actions a,.pch-extra-actions button{display:flex;justify-content:center;align-items:center;min-height:44px;border:1px solid #14284B;border-radius:10px;padding:9px;background:#14284B;color:#fff;text-decoration:none;text-align:center;font-size:12px;font-weight:800;cursor:pointer}',
      '.pch-bybit{margin:8px auto 18px;max-width:1076px;padding:15px 18px;border:2px solid #14284B;border-radius:17px;background:linear-gradient(125deg,#F7A600,#FFE083 72%,#FFF3C5);color:#14284B;display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:center;gap:14px;box-shadow:0 10px 20px -17px rgba(247,166,0,.9)}',
      '.pch-bybit-badge{display:inline-flex;align-items:center;gap:6px;font-size:10px;letter-spacing:.14em;text-transform:uppercase;font-weight:900;background:#14284B;color:#FFD24D;border-radius:999px;padding:6px 10px;margin-bottom:9px}',
      '.pch-bybit h2{font-size:clamp(20px,3vw,29px);line-height:1.1;margin:0 0 8px;color:#14284B}',
      '.pch-bybit p{font-size:13.5px;line-height:1.55;margin:0;color:#263B53;max-width:690px}',
      '.pch-bybit small{display:block;font-size:11px;line-height:1.45;color:#435067;margin-top:8px;max-width:760px}',
      '.pch-bybit a{display:inline-flex;justify-content:center;align-items:center;min-height:48px;padding:0 19px;border-radius:12px;background:#14284B;color:#FFD24D;text-decoration:none;font-weight:900;white-space:nowrap;box-shadow:0 6px 12px -8px rgba(20,40,75,.8)}',
      '.pch-bybit a:hover{background:#1B8A83;color:#fff}',
      '.pch-progress-track{height:7px;background:#EAF1EF;border-radius:999px;margin:0 0 16px;overflow:hidden}',
      '.pch-progress-fill{height:100%;width:10%;background:#2AA39B;border-radius:999px;transition:width .2s ease}',
      '.pch-results{margin-top:16px;padding:14px;border-radius:13px;background:#F6F9F7;border:1px solid rgba(20,40,75,.12)}',
      '.pch-review{border-top:1px solid rgba(20,40,75,.11);padding:10px 0}',
      '.pch-review summary{cursor:pointer;font-size:13px;font-weight:800;color:#14284B;line-height:1.4}',
      '.pch-review p{font-size:13px;line-height:1.55;color:#44556B;margin:7px 0 0}',
      '.pch-results-note{font-size:12px;line-height:1.5;color:#55657C;margin-top:9px}',
      '.pch-bottom-nav{position:fixed;z-index:8000;left:10px;right:10px;bottom:calc(6px + env(safe-area-inset-bottom));max-width:360px;margin:0 auto;padding:5px;display:grid;grid-template-columns:minmax(0,1fr);gap:4px;border:1px solid rgba(255,255,255,.25);border-radius:15px;background:rgba(20,40,75,.98);box-shadow:0 10px 24px rgba(20,40,75,.27);backdrop-filter:blur(12px)}',
      '.pch-bottom-nav a{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;min-width:0;min-height:54px;padding:6px 3px;border-radius:10px;background:rgba(255,255,255,.07);color:#fff;text-decoration:none;font-weight:800;font-size:11px;line-height:1.15;text-align:center}',
      '.pch-bottom-nav a span{font-size:17px;line-height:1}',
      '.pch-bottom-nav a.ativo{background:#2AA39B;color:#062F35}',
      '.pch-bottom-nav small{font-size:10.5px;white-space:normal}',
      
      '.pch-bottom-nav a:hover{background:#71D3C9;color:#062F35}',
      '.pch-footer{max-width:1120px;margin:0 auto;padding:20px 22px 28px;border-top:1px solid rgba(20,40,75,.10);display:flex;justify-content:space-between;align-items:center;gap:15px;flex-wrap:wrap;color:#55657C;font-size:12px}',
      '.pch-footer-links{width:100%;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:9px}',
      '.pch-footer-links a{display:flex;justify-content:center;align-items:center;min-height:48px;padding:10px 12px;border-radius:12px;background:#14284B;color:#fff!important;text-decoration:none!important;text-align:center;font-size:12px;font-weight:800;line-height:1.25;box-shadow:0 6px 14px -12px rgba(20,40,75,.9)}',
      '.pch-footer-links a:hover{background:#1B8A83}',
      '.pch-home button:focus-visible,.pch-home a:focus-visible{outline:3px solid #2AA39B;outline-offset:3px}',
      '@media(max-width:740px){.pch-header{padding:14px 16px}.pch-main{padding:4px 14px 28px}.pch-hero{grid-template-columns:1fr;gap:20px;padding:25px 20px;border-radius:21px}.pch-title{font-size:clamp(34px,9vw,46px)}.pch-proof{padding:17px}.pch-benefits{padding-top:30px}.pch-benefit-grid{grid-template-columns:1fr;gap:9px;margin-top:15px}.pch-benefit{min-height:0;padding:15px}.pch-benefit-num{margin-bottom:9px}.pch-offer-top{display:block}.pch-products{gap:7px}.pch-product{padding:8px;border-radius:11px}.pch-product img{width:38px;height:44px}.pch-product strong{font-size:10.5px;min-height:42px}.pch-product-price{font-size:11px;margin:7px 0}.pch-product button{font-size:11px;min-height:38px}.pch-combo-items{display:flex;gap:7px;overflow-x:auto;scroll-snap-type:x mandatory;padding-bottom:4px}.pch-combo-item{min-width:132px;max-width:160px;scroll-snap-align:start;align-items:flex-start;flex-direction:column}.pch-combo-item img{width:34px;height:40px}.pch-combo-item strong{font-size:11px}.pch-buy-row{align-items:stretch;flex-direction:column}.pch-buy{width:100%}.pch-choices{grid-template-columns:1fr}.pch-extra-actions{grid-template-columns:1fr}.pch-footer{padding:18px 14px 24px}.pch-footer-links{grid-template-columns:1fr;gap:8px}.pch-footer-links a{font-size:14px;min-height:50px}.pch-brand strong{font-size:10.5px}.pch-brand img{width:40px;height:40px}.pch-bybit{margin-left:14px;margin-right:14px;grid-template-columns:1fr}.pch-bybit>a{width:100%}.pch-after3{padding:13px}}',
      '@media(max-width:740px){.pch-hero.pch-hero-compact{padding:20px 18px;gap:8px}.pch-hero-compact .pch-title{font-size:clamp(30px,8.2vw,39px);line-height:1.04;margin-bottom:9px}.pch-hero-compact .pch-lead{font-size:13.5px;line-height:1.45}.pch-bottom-nav{left:8px;right:8px;padding:5px;gap:4px}.pch-bottom-nav a{min-height:52px}.pch-bottom-nav small{font-size:10px}}',
      '@media(prefers-reduced-motion:reduce){.pch-home *{scroll-behavior:auto!important;transition:none!important}}'
    ].join('');
    document.head.appendChild(style);
  }
  app.innerHTML = [
    '<div class="pch-home">',
      '<header class="pch-header">',
        '<a class="pch-brand" href="/cursos" aria-label="Plataforma Curso, página inicial"><img src="/curso-logo.png" alt=""><span><strong>PLATAFORMA CURSO</strong><small class="pch-lema"></small></span></a>',
        '<a class="pch-header-link" href="/cursos?aprender=1" data-pch-start="1">', (temContaAluno() ? 'Continuar a aprender' : 'Entrar'), '</a>',
      '</header>',
      '<main class="pch-main">',
        '<section class="pch-hero pch-hero-compact" aria-labelledby="pchTitle">',
          '<div><p class="pch-kicker">FORMAÇÃO PRÁTICA, AO SEU RITMO</p>',
          '<h1 class="pch-title" id="pchTitle">Aprenda algo útil. Avance ao seu ritmo.</h1>',
          '<p class="pch-lead">Diga o que quer alcançar e comece a aprender no telemóvel, com um percurso ajustado ao seu objectivo.</p>',
          '<div class="pch-actions"><button type="button" class="pch-primary" data-pch-start="1">', (temContaAluno() ? 'Continuar as minhas aulas' : 'Começar grátis'), '</button></div>',
          '<p class="pch-free-note">Diagnóstico e nível básico gratuitos.</p></div>',
        '</section>',
        '<section class="pch-offer" id="pchOferta" style="display:none" aria-labelledby="pchOfferTitle">',
          '<div class="pch-offer-top"><div><p class="pch-section-kicker">LIVROS E FERRAMENTAS</p><h2 class="pch-h2" id="pchOfferTitle">Escolha só o que precisa.</h2><p>Compre um recurso individual ou leve os três juntos no combo. A biblioteca completa fica à parte.</p></div></div>',
          '<div id="pchIndividualSlot" class="pch-products" aria-live="polite"></div>',
          '<div id="pchComboPart" style="display:none"><div class="pch-offer-divider">OU LEVE O COMBO</div><div id="pchComboSlot" aria-live="polite"></div></div>',
        '</section>',
        '<section class="pch-challenges" aria-labelledby="pchChallengeTitle"><p class="pch-section-kicker">TREINE A MENTE</p><h2 class="pch-h2" id="pchChallengeTitle">Desafios psicotécnicos e de lógica</h2><p style="margin:9px 0 0;color:#55657C;font-size:14px;line-height:1.55;">Responda a 10 perguntas variadas e carregue em Avançar. A pontuação e as explicações só aparecem no final. Exercício de treino, não diagnóstico clínico.</p>',
          '<div class="pch-challenge-card"><div class="pch-challenge-head"><span class="pch-tag" id="pchChallengeProgress">Pergunta 1 de 10</span><span class="pch-tag" id="pchChallengeType">Raciocínio</span></div>',
            '<div class="pch-progress-track" role="progressbar" aria-label="Progresso do teste" aria-valuemin="0" aria-valuemax="10" aria-valuenow="0"><div class="pch-progress-fill" id="pchProgressBar" style="width:0%"></div></div>',
            '<h3 class="pch-question" id="pchQuestion"></h3><div class="pch-choices" id="pchChoices"></div>',
            '<div class="pch-feedback" id="pchFeedback" hidden aria-live="polite"></div><div class="pch-results" id="pchResults" hidden aria-live="polite"></div>',
            '<div class="pch-challenge-actions"><button type="button" id="pchCheck" disabled>Avançar</button><button type="button" id="pchNext" hidden>Novo teste</button></div>',
            '<div class="pch-after3" id="pchAfter3" hidden><h3>Continue a sua evolução</h3><p>Já concluiu rondas de treino. Crie uma conta para guardar o seu progresso e os cursos do ANNAN. Também pode instalar a aplicação ou convidar 10 amigos para resolverem os desafios. Os resultados e as explicações continuam gratuitos.</p>',
              '<div class="pch-extra-actions"><a href="/cursos?aprender=1" data-pch-account="1">Criar conta</a><span>A aplicação Android está em preparação</span><button type="button" id="pchInvite10">Convidar 10 amigos</button></div>',
            '</div>',
          '</div>',
        '</section>',
      '</main>',
      '<section class="pch-bybit" aria-labelledby="pchBybitTitle"><div><span class="pch-bybit-badge">BYBIT</span><h2 id="pchBybitTitle">Obtenha uma conta Visa</h2><p>Aceda à página oficial da Bybit e consulte as condições antes de solicitar.</p><small>A disponibilidade do cartão depende do país de residência e da elegibilidade.</small></div><a href="https://www.bybit.com/cards/?ref=AGBWMZV&source=applet_invite" target="_blank" rel="noopener sponsored noreferrer">Obtenha uma conta Visa ↗</a></section>',
      '<footer class="pch-footer"><span>Plataforma Curso · Formação ao seu ritmo</span></footer>',
      '<nav class="pch-bottom-nav" aria-label="Acesso rápido"><a href="/cursos?aprender=1" data-pch-start="1"><span aria-hidden="true">●</span><small>Área do aluno</small></a></nav>',
    '</div>'
  ].join('');
  var lema = document.querySelector('.pch-lema');
  if(lema) lema.textContent = MARCA_CURSO.lema || 'Aprender transforma possibilidades.';
  app.querySelectorAll('[data-pch-start]').forEach(function(button){
    button.addEventListener('click', function(event){ event.preventDefault(); irParaAprender(); });
  });
  carregarComboPaginaInicial();
  iniciarDesafiosHome();
  if(new URLSearchParams(location.search).get('psico') === '1') setTimeout(function(){ document.querySelector('.pch-challenges')?.scrollIntoView({behavior:'smooth',block:'start'}); }, 350);
}
async function carregarComboPaginaInicial(){
  try{
    await Promise.all([carregarCatalogoVitrine(), pcCarregarUsd().catch(function(){ return null; })]);
    var cat = catalogoVitrineCache || {};
    var lista = (cat.digitais || []).concat((cat.cursos || []).filter(function(p){ return p.curso_modalidade === 'online' && !ehCursoAlfaiataria(p); }));
    var porId = Object.create(null);
    lista.forEach(function(p){ porId[String(p.id)] = p; });
    var ordem = function(a,b){ return (Number(b.prioridade_divulgacao)||1)-(Number(a.prioridade_divulgacao)||1) || (Number(b.vendas_count)||0)-(Number(a.vendas_count)||0); };
    var individuais = (cat.digitais || []).filter(function(p){ return p.tipo !== 'combo' && p.ativo !== false; }).sort(ordem).slice(0,3);
    var combos = (cat.digitais || []).filter(function(p){ return p.tipo === 'combo' && p.ativo !== false; });
    var combo = combos.find(function(p){ return p.combo_do_dia && Array.isArray(p.combo_itens) && p.combo_itens.length === 3; })
      || combos.find(function(p){ return Array.isArray(p.combo_itens) && p.combo_itens.length === 3; }) || combos[0] || null;
    var items = combo && Array.isArray(combo.combo_itens) ? combo.combo_itens.map(function(id){ return porId[String(id)]; }).filter(Boolean).slice(0,3) : [];
    var section = document.getElementById('pchOferta');
    var productSlot = document.getElementById('pchIndividualSlot');
    var comboPart = document.getElementById('pchComboPart');
    if(!section || !productSlot) return;
    if(individuais.length){
      productSlot.innerHTML = individuais.map(function(p){
        var img = p.imagem_url || pcImagem(p);
        var preco = Number(promocaoAtiva(p) ? p.preco_promocional : p.preco || 0);
        return '<article class="pch-product"><img src="' + escAttr(img) + '" alt="' + escAttr(pcNome(p)) + '" loading="lazy"><strong>' + esc(pcNome(p)) + '</strong><span class="pch-product-price">' + pcValorHTML(preco,p.moeda) + '</span><button type="button" data-pch-buy="' + escAttr(p.id) + '">Comprar</button></article>';
      }).join('');
      productSlot.querySelectorAll('[data-pch-buy]').forEach(function(button){
        button.addEventListener('click',function(){
          var p = individuais.find(function(x){ return String(x.id) === String(button.getAttribute('data-pch-buy')); });
          if(!p) return;
          if(window.medirProduto) medirProduto(p.id,'carrinho');
          compraRapida(p);
        });
      });
    }else{
      productSlot.innerHTML = '<p style="font-size:13px;color:#55657C;margin:8px 0 0;">Novos recursos digitais a caminho.</p>';
    }
    if(combo && comboPart){
      var exatosTres = items.length === 3;
      var precoCombo = Number(promocaoAtiva(combo) ? combo.preco_promocional : combo.preco || 0);
      var soma = exatosTres ? items.reduce(function(total,p){ return total + Number(promocaoAtiva(p) ? p.preco_promocional : p.preco || 0); },0) : 0;
      var itensHTML = exatosTres
        ? '<div class="pch-combo-items">' + items.map(function(p,i){
            return '<article class="pch-combo-item"><img src="' + escAttr(p.imagem_url || pcImagem(p)) + '" alt="' + escAttr(pcNome(p)) + '" loading="lazy"><div><small>RECURSO ' + (i+1) + '</small><strong>' + esc(pcNome(p)) + '</strong></div></article>';
          }).join('') + '</div>'
        : '<div class="pch-combo-fallback"><img src="' + escAttr(combo.imagem_url || pcImagem(combo)) + '" alt="' + escAttr(pcNome(combo)) + '" loading="lazy"><div><h3>' + esc(pcNome(combo)) + '</h3><p>' + esc(combo.descricao || 'Uma oferta reunida num único produto.') + '</p></div></div>';
      var comboSlot = document.getElementById('pchComboSlot');
      if(comboSlot){
        comboSlot.innerHTML = '<div class="pch-combo-card">' + itensHTML + '<div class="pch-buy-row"><div><div class="pch-price">' + pcValorHTML(precoCombo,combo.moeda,soma > precoCombo ? soma : null) + '</div><div class="pch-price-note">' + (soma > precoCombo ? 'Os três juntos; compare com o preço individual.' : 'Preço publicado da oferta.') + '</div></div><button type="button" class="pch-buy" id="pchComprarCombo">Comprar combo</button></div></div>';
        document.getElementById('pchComprarCombo').addEventListener('click',function(){
          if(window.medirProduto) medirProduto(combo.id,'carrinho');
          compraRapida(combo);
        });
      }
      comboPart.style.display = '';
    }
    section.style.display = individuais.length || combo ? '' : 'none';
  }catch(error){
    console.warn('Produtos da página inicial indisponíveis:', error && error.message ? error.message : error);
  }
}
function iniciarDesafiosHome(){
  var KEY_SEEN = 'pc_psico_perguntas_v3';
  var KEY_ROUNDS = 'pc_desafios_rodadas_v2';
  var KEY_PROFILE = 'pc_psico_perfil_v3';
  function rand(min,max){ return Math.floor(Math.random()*(max-min+1))+min; }
  function pick(a){ return a[rand(0,a.length-1)]; }
  function shuffle(a){
    var b=a.slice();
    for(var i=b.length-1;i>0;i--){ var j=rand(0,i); var t=b[i]; b[i]=b[j]; b[j]=t; }
    return b;
  }
  function uniqueStrings(a){
    var out=[];
    a.forEach(function(x){ var v=String(x); if(out.indexOf(v)<0) out.push(v); });
    return out;
  }
  function fingerprint(type,q,options){
    return String(type+'|'+q+'|'+options.map(String).slice().sort().join('|'))
      .toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').slice(0,1000);
  }
  function scored(type,q,answer,distractors,explanation){
    var correct=String(answer);
    var options=uniqueStrings([correct].concat(distractors||[]));
    var backups=['Nenhuma das anteriores','Não é possível determinar','Outra combinação','Opção diferente'];
    for(var i=0;options.length<4 && i<backups.length;i++){
      if(options.indexOf(backups[i])<0) options.push(backups[i]);
    }
    options=shuffle(options.slice(0,4));
    return {type:type,q:q,o:options,a:options.indexOf(correct),e:explanation,scored:true,id:fingerprint(type,q,options)};
  }
  function profileQuestion(slot){
    var scenarios=[
      'Quando recebe um objectivo difícil e novo, qual é a primeira abordagem que mais combina consigo?',
      'Quando uma tentativa não resulta à primeira, o que tende a fazer?',
      'Ao começar uma tarefa com prazo apertado, como costuma organizar-se?',
      'Quando tem de aprender uma competência nova, por onde prefere começar?',
      'Num projecto em grupo, que papel costuma assumir espontaneamente?',
      'Perante um problema sem resposta óbvia, como prefere avançar?',
      'Quando recebe uma tarefa que nunca fez, o que lhe dá mais confiança?',
      'Se tem pouco tempo para decidir, qual abordagem prefere?'
    ];
    var options=[
      {label:slot===0?'Divido em etapas e defino uma ordem.':'Defino prioridades, passos e prazos.',trait:'planeamento'},
      {label:slot===0?'Experimento uma hipótese pequena e observo.':'Faço um teste prático e ajusto com o resultado.',trait:'experimentacao'},
      {label:slot===0?'Troco ideias e comparo pontos de vista.':'Peço contributos e construo uma solução com outros.',trait:'colaboracao'},
      {label:slot===0?'Exploro primeiro por conta própria.':'Tento uma primeira solução autonomamente.',trait:'autonomia'}
    ];
    var opts=shuffle(options);
    var labels=opts.map(function(x){return x.label;});
    var traits=opts.map(function(x){return x.trait;});
    var q=pick(scenarios);
    return {type:'Preferências pessoais',q:q,o:labels,a:null,e:'Não existe resposta certa ou errada. Esta escolha regista apenas a abordagem que prefere neste cenário.',scored:false,profileTraits:traits,id:fingerprint('Preferências pessoais',q,labels)};
  }
  function genSequence(){
    var mode=rand(0,4), start, step, vals, ans, shown, typ;
    if(mode===0){
      start=rand(2,60); step=rand(2,13); vals=[];
      for(var i=0;i<5;i++) vals.push(start+i*step);
      shown=vals.slice(0,4); ans=vals[4]; typ='Sequência numérica';
      return scored(typ,'Qual é o próximo número? '+shown.join(', ')+', …',ans,[ans+step,ans-step,ans+step*2],'A sequência aumenta sempre '+step+'. Por isso, ao último valor mostrado somamos '+step+'.');
    }
    if(mode===1){
      start=rand(1,9); step=pick([2,3]); vals=[];
      for(var j=0;j<5;j++) vals.push(start*Math.pow(step,j));
      shown=vals.slice(0,4); ans=vals[4]; typ='Padrão multiplicativo';
      return scored(typ,'Qual é o próximo número? '+shown.join(', ')+', …',ans,[ans+1,ans/step,ans*step],'Cada termo é multiplicado por '+step+'. O último valor mostrado multiplicado por '+step+' dá '+ans+'.');
    }
    if(mode===2){
      start=rand(0,15); vals=[];
      for(var k=1;k<=5;k++) vals.push(start+k*k);
      shown=vals.slice(0,4); ans=vals[4]; typ='Padrão de diferenças';
      return scored(typ,'Descubra o próximo valor: '+shown.join(', ')+', …',ans,[ans+2,ans-2,ans+5],'As diferenças são quadrados consecutivos: +3, +5, +7… A próxima diferença é +9; com o início escolhido, o próximo valor é '+ans+'.');
    }
    if(mode===3){
      start=rand(3,40); var a=rand(2,8), b=rand(3,11); vals=[start];
      for(var z=1;z<5;z++) vals.push(vals[z-1]+(z%2===1?a:b));
      shown=vals.slice(0,4); ans=vals[4]; typ='Padrão alternado';
      return scored(typ,'Que número completa o padrão? '+shown.join(', ')+', …',ans,[ans+a,ans-b,ans+1],'Os aumentos alternam entre +'+a+' e +'+b+'. Depois do último valor mostrado, o próximo aumento é +'+b+'.');
    }
    start=rand(60,150); step=rand(2,9); vals=[start];
    for(var z2=1;z2<5;z2++) vals.push(vals[z2-1]-(step+z2-1));
    shown=vals.slice(0,4); ans=vals[4]; typ='Sequência decrescente';
    return scored(typ,'Qual valor vem a seguir? '+shown.join(', ')+', …',ans,[ans-1,ans+step,ans-3],'As subtracções aumentam de um em um: −'+step+', −'+(step+1)+', −'+(step+2)+'… A próxima é −'+(step+3)+'.');
  }
  function genNumerical(){
    var mode=rand(0,4), amount, pct, answer, wrong, unit, qty, people, rate, hours, speed, time, price, cost, margin;
    if(mode===0){
      price=rand(5,30)*100; pct=pick([10,15,20,25,30,40,50]); amount=price*pct/100; answer=price-amount;
      return scored('Aptidão numérica','Um artigo custa '+price.toLocaleString('pt-PT')+' Kz e tem desconto de '+pct+'%. Quanto se paga no final?',answer,[answer+amount/2,price+amount,amount],'Calculamos '+pct+'% de '+price+' Kz ('+amount+' Kz) e subtraímos o desconto ao preço original. O preço final é '+answer+' Kz.');
    }
    if(mode===1){
      people=rand(2,8); rate=rand(3,16); hours=rand(2,6); answer=people*rate*hours;
      return scored('Desempenho e produtividade',people+' trabalhadores fazem '+rate+' unidades cada um por hora. Quantas unidades fazem em '+hours+' horas, mantendo o mesmo ritmo?',answer,[answer+rate,answer-rate,people*rate],'Produção total = trabalhadores × unidades por hora × horas: '+people+' × '+rate+' × '+hours+' = '+answer+'.');
    }
    if(mode===2){
      unit=pick([75,100,125,150,200,250,300,400,500]); qty=rand(3,8); var target=rand(4,9); answer=unit*target;
      return scored('Proporção','Se '+qty+' unidades custam '+(unit*qty).toLocaleString('pt-PT')+' Kz, quanto custam '+target+' unidades ao mesmo preço por unidade?',answer,[answer+unit,answer-unit,unit*qty],'Preço por unidade = '+(unit*qty)+' ÷ '+qty+' = '+unit+' Kz. Para '+target+' unidades: '+unit+' × '+target+' = '+answer+' Kz.');
    }
    if(mode===3){
      speed=pick([30,40,50,60,70,80,90,100]); time=rand(2,5); answer=speed*time;
      return scored('Aptidão quantitativa','Um veículo mantém '+speed+' km/h durante '+time+' horas. Que distância percorre?',answer,[answer+speed,answer-speed,speed+time],'Distância = velocidade × tempo: '+speed+' × '+time+' = '+answer+' km.');
    }
    cost=rand(8,60)*100; margin=pick([10,15,20,25,30,40]); answer=cost*(100+margin)/100;
    return scored('Raciocínio comercial','Um produto custa '+cost.toLocaleString('pt-PT')+' Kz à empresa. Ao aplicar uma margem sobre o custo de '+margin+'%, qual é o preço de venda antes de outras despesas?',answer,[cost*margin/100,cost+margin,cost*(100-margin)/100],'Margem sobre o custo = '+cost+' × '+margin+'% = '+(cost*margin/100)+' Kz. Preço de venda = custo + margem = '+answer+' Kz. Este é um exercício didáctico, não uma recomendação de preço real.');
  }
  function genLogic(){
    var starts=['o sensor recebeu um sinal válido','o código de acesso passou na validação','o pedido foi confirmado','a ficha passou na revisão','a reserva foi validada','o pagamento foi confirmado','o documento foi aprovado','o sistema recebeu todos os dados necessários'];
    var middles=['o sistema regista o evento','a etapa seguinte fica activa','o processo é enviado para execução','a notificação é preparada','o painel actualiza o estado','o relatório é colocado em fila','a tarefa é encaminhada para tratamento','a sessão passa para o estado seguinte'];
    var ends=['o operador recebe a tarefa','é emitido um relatório','o resultado fica disponível','o controlo seguinte é iniciado','a equipa recebe o aviso','a acção final é preparada','o registo aparece no histórico','o processo fica pronto para a próxima etapa'];
    var a=pick(starts), b=pick(middles), c=pick(ends);
    var d1=pick(starts.filter(function(x){return x!==a;}));
    var d2=pick(middles.filter(function(x){return x!==b;}));
    var d3=pick(ends.filter(function(x){return x!==c;}));
    var q='Regra 1: sempre que '+a+', acontece que '+b+'. Regra 2: sempre que '+b+', acontece que '+c+'. Sabemos que '+a+'. Qual conclusão é garantida?';
    return scored('Dedução lógica',q,c,[d1,d2,'Nenhuma conclusão pode ser tirada'],'Aplicando as duas regras em cadeia: '+a+' implica que '+b+' acontece; por sua vez, '+b+' implica que '+c+'. Logo, a conclusão garantida é: '+c+'.');
  }
  function genAttention(){
    var length=rand(12,20), target=String(rand(0,9)), code='', count=0;
    for(var i=0;i<length;i++){ var digit=String(rand(0,9)); code+=digit; if(digit===target) count++; }
    var wrong=[count+1,Math.max(0,count-1),count+2];
    return scored('Atenção e concentração','Observe o código '+code+'. Quantas vezes aparece o dígito '+target+'?',count,wrong,'Contando cada ocorrência do dígito '+target+' no código, encontramos '+count+'. O objectivo é focar-se no alvo e ignorar os restantes números.');
  }
  function genMemory(){
    var alphabet='23456789ABCDEFGHJKLMNPQRSTUVWXYZ', code='', len=rand(6,9);
    for(var i=0;i<len;i++) code+=alphabet[rand(0,alphabet.length-1)];
    var pos=rand(2,len-1), answer=code.charAt(pos-1), wrong=uniqueStrings([code.charAt((pos)%len),code.charAt((pos+1)%len),alphabet.charAt((alphabet.indexOf(answer)+rand(1,8))%alphabet.length)]);
    if(wrong.length<3) wrong=uniqueStrings(wrong.concat(['X','Y','Z']));
    return scored('Memória de trabalho','Leia a sequência '+code+'. Qual símbolo estava na posição '+pos+'?',answer,wrong.slice(0,3),'Contando da esquerda para a direita, o símbolo na posição '+pos+' da sequência é '+answer+'. Estratégia: divida mentalmente a sequência em pequenos grupos.');
  }
  function genSpatial(){
    var x=rand(-7,7), y=rand(-7,7), east=rand(1,6), north=rand(1,6), west=rand(1,6), south=rand(1,6);
    var fx=x+east-west, fy=y+north-south, answer='('+fx+', '+fy+')';
    var wrong=uniqueStrings(['('+(fx+1)+', '+fy+')','('+fx+', '+(fy+1)+')','('+(fx-east-west)+', '+(fy+south+north)+')']);
    return scored('Raciocínio espacial','Uma peça começa no ponto ('+x+', '+y+'). Move-se '+east+' casas para este, '+north+' para norte, '+west+' para oeste e '+south+' para sul. Em que ponto termina?',answer,wrong,'No eixo horizontal: '+x+' + '+east+' − '+west+' = '+fx+'. No vertical: '+y+' + '+north+' − '+south+' = '+fy+'. Resultado: '+answer+'.');
  }
  function genProbability(){
    var red=rand(1,9), blue=rand(1,9), total=red+blue, answer=red+'/'+total;
    var wrong=uniqueStrings([blue+'/'+total,red+'/'+(total+1),'1/'+total,(red+1)+'/'+total]);
    return scored('Probabilidade','Um saco tem '+red+' peças vermelhas e '+blue+' azuis. Retirando uma peça ao acaso, qual é a probabilidade de sair vermelha?',answer,wrong.slice(0,3),'Há '+red+' resultados favoráveis entre '+total+' peças. A probabilidade é '+red+'/'+total+'; não é necessário calcular a percentagem para comparar as opções.');
  }
  function genVerbal(){
    var relations=[
      {item:'termómetro',act:'medir a temperatura'},{item:'bússola',act:'indicar a direcção'},{item:'tesoura',act:'cortar'},{item:'relógio',act:'medir o tempo'},
      {item:'lupa',act:'ampliar'},{item:'chave',act:'abrir uma fechadura'},{item:'balança',act:'medir a massa'},{item:'lápis',act:'escrever'},
      {item:'escova',act:'limpar ou pentear'},{item:'filtro',act:'separar partículas'},{item:'mapa',act:'orientar uma deslocação'},{item:'régua',act:'medir comprimento'},
      {item:'microscópio',act:'observar objectos muito pequenos'},{item:'lanterna',act:'iluminar'},{item:'funil',act:'guiar líquidos para uma abertura'},{item:'calculadora',act:'efectuar cálculos'},
      {item:'cadeado',act:'proteger um acesso'},{item:'martelo',act:'pregar ou golpear'},{item:'peneira',act:'separar por tamanho'},{item:'binóculos',act:'aproximar a visão de objectos distantes'}
    ];
    var left=pick(relations), right=pick(relations.filter(function(x){return x.item!==left.item;}));
    var wrong=shuffle(relations.filter(function(x){return x.act!==right.act && x.item!==left.item && x.item!==right.item;})).slice(0,3).map(function(x){return x.act;});
    return scored('Raciocínio verbal','A relação é objecto e função: '+left.item+' serve para '+left.act+'. Da mesma forma, '+right.item+' serve para…?',right.act,wrong,'A analogia compara cada objecto com a sua função mais característica. '+right.item+' serve para '+right.act+'.');
  }
  function genPerformance(){
    var minutes=rand(8,35), units=rand(4,30), scenario=pick([
      'uma encomenda de '+units+' unidades está quase pronta',
      'um relatório com '+units+' registos tem entrega prevista',
      'uma tarefa com '+units+' etapas está perto do prazo',
      'um lote de '+units+' peças precisa de verificação final',
      'uma operação com '+units+' itens aguarda confirmação'
    ]);
    var q='Faltam '+minutes+' minutos para entregar '+scenario+', mas detecta uma falha que pode comprometer a segurança ou a qualidade. Qual é a melhor primeira decisão?';
    var answer='Conter o risco, verificar/corrigir a falha e informar o responsável; depois actualizar o prazo.';
    return scored('Desempenho e decisão',q,answer,[
      'Ignorar a falha para cumprir o prazo a qualquer custo.',
      'Enviar o trabalho sem verificar e esperar que ninguém repare.',
      'Ocultar o problema e continuar exactamente como antes.'
    ],'Quando há risco para pessoas, dados ou qualidade, a prioridade é conter o risco e comunicar com clareza. Depois, replaneia-se a entrega com informação real.');
  }
  var scenariosThisRound=[];
  function genProfile(slot){
    var prompts=[
      'Ao iniciar um objectivo difícil e novo, qual abordagem mais combina consigo?',
      'Quando uma tentativa não resulta à primeira, o que tende a fazer?',
      'Num projecto em equipa, que papel assume mais naturalmente?',
      'Quando tem de aprender uma competência nova, como prefere começar?',
      'Perante um problema sem resposta óbvia, o que faz primeiro?',
      'Se o prazo é curto e há várias tarefas, como organiza o trabalho?',
      'Quando recebe uma crítica construtiva, qual é a sua reacção habitual?',
      'Ao decidir entre várias soluções possíveis, qual abordagem prefere?'
    ];
    var scenario;
    for(var s=0;s<20;s++){ scenario=pick(prompts); if(scenariosThisRound.indexOf(scenario)<0) break; }
    scenariosThisRound.push(scenario);
    var opts=[
      {label:'Defino passos, prioridades e prazos.',trait:'planeamento'},
      {label:'Faço um teste pequeno e ajusto com os resultados.',trait:'experimentacao'},
      {label:'Oiço outras perspectivas e construo uma solução em conjunto.',trait:'colaboracao'},
      {label:'Exploro uma primeira solução por conta própria.',trait:'autonomia'}
    ];
    if(slot===1){
      opts=[
        {label:'Revejo o plano e identifico o ponto que falhou.',trait:'planeamento'},
        {label:'Experimento uma abordagem diferente e comparo o efeito.',trait:'experimentacao'},
        {label:'Peço uma segunda opinião para ver o que me escapou.',trait:'colaboracao'},
        {label:'Tento resolver mais uma vez de forma independente.',trait:'autonomia'}
      ];
    }
    opts=shuffle(opts);
    var labels=opts.map(function(x){return x.label;});
    return {type:'Preferências e personalidade',q:scenario,o:labels,a:null,e:'Não existe resposta certa ou errada. Esta escolha serve para observar a abordagem que prefere, não para diagnosticar a sua personalidade.',scored:false,profileTraits:opts.map(function(x){return x.trait;}),id:fingerprint('Preferências e personalidade',scenario,labels)};
  }
  var seen=[];
  var storedRounds=0;
  try{ seen=JSON.parse(localStorage.getItem(KEY_SEEN)||'[]'); if(!Array.isArray(seen)) seen=[]; }catch(_e){seen=[];}
  var seenSet=new Set(seen);
  try{ storedRounds=Number(localStorage.getItem(KEY_ROUNDS)||0)||0; }catch(_e){storedRounds=0;}
  var rondas=storedRounds, questoesDaRonda=[], indice=0, escolhida=null, respostas=[], concluido=false;
  var pergunta=document.getElementById('pchQuestion'), opcoes=document.getElementById('pchChoices'), feedback=document.getElementById('pchFeedback'), resultados=document.getElementById('pchResults');
  var botaoAvancar=document.getElementById('pchCheck'), botaoNovo=document.getElementById('pchNext'), progresso=document.getElementById('pchChallengeProgress'), tipo=document.getElementById('pchChallengeType'), barra=document.getElementById('pchProgressBar'), trilho=barra&&barra.parentElement;
  var convite=document.getElementById('pchInvite10'), after=document.getElementById('pchAfter3');
  if(!pergunta||!opcoes||!botaoAvancar||!botaoNovo||!resultados) return;
  function bar(v){if(barra)barra.style.width=String(v)+'%';if(trilho)trilho.setAttribute('aria-valuenow',String(Math.round(v/10)));}
  function makeUnique(maker,sessionSet){
    var item=null;
    for(var attempts=0;attempts<300;attempts++){
      item=maker();
      if(item&&!seenSet.has(item.id)&&!sessionSet.has(item.id)){
        sessionSet.add(item.id); seenSet.add(item.id); seen.push(item.id); return item;
      }
    }
    return item;
  }
  function buildRound(){
    scenariosThisRound=[];
    var middle=(rondas%2===0)?genProbability:genVerbal;
    var makers=[genSequence,genNumerical,genLogic,genAttention,genMemory,genSpatial,middle,genPerformance,function(){return genProfile(0);},function(){return genProfile(1);}];
    var set=new Set(), round=[];
    makers.forEach(function(maker){ var q=makeUnique(maker,set); if(q)round.push(q); });
    round=shuffle(round);
    while(round.length<10){var q=makeUnique(genSequence,set);if(!q)break;round.push(q);}
    questoesDaRonda=round.slice(0,10);
    if(seen.length>2500){seen=seen.slice(-2500);seenSet=new Set(seen);}
    try{localStorage.setItem(KEY_SEEN,JSON.stringify(seen));}catch(_e){}
  }
  function hideResults(){
    if(feedback)feedback.hidden=true;
    resultados.hidden=true;
    resultados.replaceChildren();
  }
  function paintQuestion(){
    var item=questoesDaRonda[indice];
    if(!item)return;
    escolhida=null; progresso.textContent='Pergunta '+(indice+1)+' de 10';tipo.textContent=item.type;
    pergunta.textContent=item.q;opcoes.hidden=false;opcoes.replaceChildren();hideResults();bar(indice*10);
    botaoAvancar.hidden=false;botaoAvancar.disabled=false;botaoAvancar.textContent='Avançar';botaoNovo.hidden=true;
    if(after)after.hidden=true;
    item.o.forEach(function(label,i){
      var button=document.createElement('button');button.type='button';button.className='pch-choice';button.textContent=String.fromCharCode(65+i)+') '+label;
      button.addEventListener('click',function(){
        if(concluido)return;escolhida=i;
        opcoes.querySelectorAll('.pch-choice').forEach(function(x){x.classList.remove('selecionada');});
        button.classList.add('selecionada');botaoAvancar.disabled=false;
      });
      opcoes.appendChild(button);
    });
  }
  function saveProfile(responses){
    var totals={planeamento:0,experimentacao:0,colaboracao:0,autonomia:0};
    try{var old=JSON.parse(localStorage.getItem(KEY_PROFILE)||'{}');if(old&&typeof old==='object')Object.keys(totals).forEach(function(k){totals[k]=Number(old[k])||0;});}catch(_e){}
    responses.forEach(function(r){if(r.item.scored===false&&r.item.profileTraits&&r.item.profileTraits[r.escolhida])totals[r.item.profileTraits[r.escolhida]]++;});
    try{localStorage.setItem(KEY_PROFILE,JSON.stringify(totals));}catch(_e){}
    return totals;
  }
  function courseSuggestions(score,total,weakTypes){
    if(total===0||score/total>=0.55)return '';
    var weak=weakTypes.length?weakTypes.slice(0,3).join(', '):'raciocínio geral';
    return '<div class="pch-after3" style="margin-top:14px"><h3>Quer reforçar as bases?</h3><p>O seu resultado sugere que vale a pena praticar mais. O ANNAN pode preparar um curso guardado na sua conta, focado em: '+esc(weak)+'. Escolha a carga horária: básico 1–2 h, intermédio 6 h ou avançado 14 h.</p><div class="pch-extra-actions"><button type="button" data-pch-course-level="basico">Básico · 1–2 h</button><button type="button" data-pch-course-level="intermedio">Intermédio · 6 h</button><button type="button" data-pch-course-level="avancado">Avançado · 14 h</button></div><p id="pchCursoStatus" class="pch-results-note" aria-live="polite"></p></div>';
  }
  async function requestCourse(level,button){
    var status=document.getElementById('pchCursoStatus');
    var labels={basico:{name:'Básico',hours:'1–2 horas'},intermedio:{name:'Intermédio',hours:'6 horas'},avancado:{name:'Avançado',hours:'14 horas'}};
    var selected=labels[level]||labels.basico;
    var wrong=respostas.filter(function(r){return r.item.scored!==false&&r.escolhida!==r.item.a;});
    var areas=uniqueStrings(wrong.map(function(r){return r.item.type;})).slice(0,4);
    var pedido='Criar um curso pessoal de treino psicotécnico e cognitivo, nível '+selected.name+', duração '+selected.hours+'. Foco nas áreas que o aluno precisa praticar: '+(areas.join(', ')||'raciocínio geral')+'. Incluir explicação passo a passo, exercícios variados, prática progressiva e verificação da aprendizagem. Não apresentar o curso como diagnóstico clínico.';
    var aluno=null;
    try{aluno=JSON.parse(localStorage.getItem('ens_aluno')||'null');}catch(_e){}
    if(!aluno||!aluno.id||!aluno.token){
      if(status)status.textContent='Entre ou crie a sua conta para o curso ficar guardado na sua área de aluno.';
      if(button){button.textContent='Entrar para pedir';}
      if(button)button.onclick=function(){irParaAprender();};
      return;
    }
    if(typeof sb==='undefined'||!sb.functions||!sb.functions.invoke){
      if(status)status.textContent='A ligação ao ANNAN não está disponível neste momento. O resultado ficou guardado neste dispositivo.';
      return;
    }
    if(button){button.disabled=true;button.textContent='A pedir ao ANNAN…';}
    if(status)status.textContent='A enviar o pedido para a sua conta…';
    try{
      var response=await sb.functions.invoke('annan-ensino',{body:{acao:'curso_pedir',id:aluno.id,token:aluno.token,pedido:pedido}});
      var data=response&&response.data||{};
      if(response&&response.error)throw response.error;
      if(data.erro)throw new Error(data.nota||data.erro);
      if(status)status.textContent='Pedido registado. O curso vai aparecer em “Os meus cursos” da sua conta. '+(data.nota||'');
      if(button){button.disabled=false;button.textContent='Pedido registado ✓';}
    }catch(error){
      if(status)status.textContent='Não consegui registar o pedido: '+(error&&error.message||'tente novamente dentro de momentos.');
      if(button){button.disabled=false;button.textContent='Tentar de novo';}
    }
  }
  function showResults(){
    concluido=true;rondas++;
    try{localStorage.setItem(KEY_ROUNDS,String(rondas));}catch(_e){}
    var scoredItems=respostas.filter(function(r){return r.item.scored!==false&&Number.isInteger(r.escolhida);});
    var score=scoredItems.filter(function(r){return r.escolhida===r.item.a;}).length;
    var total=scoredItems.length;
    progresso.textContent='Teste concluído · 10/10';
    tipo.textContent='Acertos '+score+'/'+total;
    pergunta.textContent='Terminou as 10 perguntas!';
    opcoes.hidden=true;bar(100);
    feedback.hidden=false;
    feedback.textContent=(total?'Acertos nas perguntas com solução objectiva: '+score+'/'+total+'. ':'Não respondeu a nenhuma pergunta com pontuação objectiva. ')+'As perguntas de preferências pessoais não são avaliadas como certas ou erradas. Veja as explicações abaixo.';
    var profileTotals=saveProfile(respostas);
    var profileSorted=Object.keys(profileTotals).sort(function(a,b){return profileTotals[b]-profileTotals[a];});
    var profileNames={planeamento:'planeamento',experimentacao:'experimentação',colaboracao:'colaboração',autonomia:'autonomia'};
    var nPerfil=respostas.filter(function(r){return r.item.scored===false&&Number.isInteger(r.escolhida);}).length;
    var profileText=nPerfil?'Preferências observadas nas suas escolhas guardadas: '+profileNames[profileSorted[0]]+' e '+profileNames[profileSorted[1]]+'. Isto é auto-observação, não um diagnóstico psicológico.':'Ainda não há respostas suficientes para resumir preferências pessoais.';
    var detail=respostas.map(function(r,i){
      var isProfile=r.item.scored===false;
      var unanswered=!Number.isInteger(r.escolhida);
      var right=!isProfile&&!unanswered&&r.escolhida===r.item.a;
      var heading=isProfile?'Preferência pessoal':(unanswered?'Saltou a pergunta':(right?'Resposta certa':'Rever resposta'));
      var answerText=unanswered?'Avançou sem responder':(r.item.o[r.escolhida]||'');
      var html='<details class="pch-review"><summary>'+String(i+1)+'. '+esc(r.item.type)+' — '+heading+'</summary><p><b>Pergunta:</b> '+esc(r.item.q)+'</p><p><b>A sua resposta:</b> '+esc(answerText)+'</p>';
      if(isProfile) html+='<p>'+esc(r.item.e)+'</p>';
      else html+='<p><b>Resposta correcta:</b> '+esc(r.item.o[r.item.a])+'</p><p>'+esc(r.item.e)+'</p>';
      return html+'</details>';
    }).join('');
    var weakTypes=uniqueStrings(respostas.filter(function(r){return r.item.scored!==false&&(!Number.isInteger(r.escolhida)||r.escolhida!==r.item.a);}).map(function(r){return r.item.type;}));
    resultados.innerHTML='<p>'+esc(profileText)+'</p>'+detail+'<p class="pch-results-note">Este é um treino educativo e de entretenimento. Não é um teste psicológico clínico nem substitui uma avaliação profissional.</p>'+courseSuggestions(score,total,weakTypes);
    resultados.hidden=false;botaoAvancar.hidden=true;botaoNovo.hidden=false;botaoNovo.textContent='Fazer outro teste';
    if(after)after.hidden=rondas<3;
    resultados.querySelectorAll('[data-pch-course-level]').forEach(function(button){button.addEventListener('click',function(){requestCourse(button.getAttribute('data-pch-course-level'),button);});});
    if(window.medirEvento)medirEvento('psico_teste_concluido');
    respostas.forEach(function(r){if(window.medirEvento&&r.item.scored!==false)medirEvento(r.escolhida===r.item.a?'desafio_acertou':'desafio_tentou');});
  }
  function newRound(){
    scenariosThisRound=[];indice=0;escolhida=null;respostas=[];concluido=false;buildRound();
    if(after)after.hidden=true;paintQuestion();
  }
  botaoAvancar.addEventListener('click',function(){
    if(concluido)return;
    respostas.push({item:questoesDaRonda[indice],escolhida:escolhida});
    if(indice<9){indice++;paintQuestion();return;}
    showResults();
  });
  botaoNovo.addEventListener('click',function(){if(concluido)newRound();});
  if(convite)convite.addEventListener('click',async function(){
    var url='https://placurso.netlify.app/cursos?psico=1&utm_source=desafio';
    try{
      var alunoConvite=JSON.parse(localStorage.getItem('ens_aluno')||'null');
      if(alunoConvite&&alunoConvite.id&&alunoConvite.token&&typeof sb!=='undefined'&&sb.functions){
        var cv=await sb.functions.invoke('annan-ensino',{body:{acao:'convite_ver',id:alunoConvite.id,token:alunoConvite.token}});
        if(!cv.error&&cv.data&&cv.data.codigo)url='https://placurso.netlify.app/cursos?c='+encodeURIComponent(cv.data.codigo)+'&psico=1&utm_source=desafio';
      }
    }catch(_e){}
    var mensagem='Desafia-te com 10 perguntas variadas de lógica, atenção, memória e aptidão na Plataforma Curso. A pontuação e as explicações aparecem no fim: '+url+'\n\nPartilha este desafio com 10 amigos.';
    try{if(navigator.share){await navigator.share({title:'Desafios do cérebro',text:mensagem,url:url});return;}}catch(_e){return;}
    window.open('https://wa.me/?text='+encodeURIComponent(mensagem),'_blank','noopener');
  });
  newRound();
}
