/* Plataforma Curso — verifica versões e só mostra o botão dentro da aplicação instalada. */
(function(){
  if(!('serviceWorker' in navigator)) return;
  var host = location.hostname;
  var isCourseSite = /^\/(cursos|infoprodutos)(\/.*)?$/.test(location.pathname)
    || /^(www\.)?(plataforma-?cu(rso)?|placurso)(-[a-z0-9]+)?\./i.test(host);
  if(!isCourseSite) return;

  var registration = null;
  var versionInUse = null;
  var bar = null;
  var observingWorker = null;
  var reloading = false;

  function isInstalledApp(){
    try{
      if(window.matchMedia && (
        window.matchMedia('(display-mode: standalone)').matches ||
        window.matchMedia('(display-mode: fullscreen)').matches
      )) return true;
    }catch(_e){}
    return navigator.standalone === true;
  }
  function scriptUrl(version){
    return '/sw-curso.js' + (version ? '?v=' + encodeURIComponent(version) : '');
  }
  async function latestVersion(){
    try{
      var response = await fetch('/pwa-version.json?check=' + Date.now(), {
        cache:'no-store',
        credentials:'same-origin'
      });
      if(!response.ok) return null;
      var data = await response.json();
      var value = String(data && data.version || '').replace(/[^A-Za-z0-9._-]/g,'').slice(0,64);
      return value || null;
    }catch(_e){
      return null;
    }
  }
  function hideBar(){
    if(bar){ bar.remove(); bar = null; }
  }
  function showIfUpdateWaiting(){
    if(!isInstalledApp() || !navigator.serviceWorker.controller || !registration || !registration.waiting) return;
    if(bar) return;
    bar = document.createElement('section');
    bar.id = 'pcUpdateBar';
    bar.setAttribute('role','status');
    bar.innerHTML = '<div><strong>Nova versão disponível</strong><span>A aplicação tem uma actualização pronta.</span></div><button type="button" id="pcUpdateBtn">Actualizar</button>';
    var style = document.getElementById('pcUpdateStyle');
    if(!style){
      style = document.createElement('style');
      style.id = 'pcUpdateStyle';
      style.textContent = '#pcUpdateBar{position:fixed;z-index:2147483647;left:12px;right:12px;bottom:calc(92px + env(safe-area-inset-bottom));max-width:580px;margin:0 auto;display:flex;align-items:center;justify-content:space-between;gap:14px;padding:13px 14px;border-radius:16px;background:#14284B;color:#fff;box-shadow:0 12px 32px rgba(0,0,0,.25);font:14px/1.35 system-ui,sans-serif}#pcUpdateBar div{min-width:0}#pcUpdateBar strong,#pcUpdateBar span{display:block}#pcUpdateBar span{opacity:.82;font-size:12px;margin-top:2px}#pcUpdateBtn{border:0;border-radius:10px;min-height:42px;padding:10px 15px;background:#2AA39B;color:#062F35;font-weight:900;white-space:nowrap;cursor:pointer}#pcUpdateBtn:disabled{opacity:.65;cursor:wait}';
      document.head.appendChild(style);
    }
    document.body.appendChild(bar);
    document.getElementById('pcUpdateBtn').addEventListener('click',function(){
      var waiting = registration && registration.waiting;
      if(!waiting) { hideBar(); return; }
      var button = document.getElementById('pcUpdateBtn');
      if(button){ button.disabled = true; button.textContent = 'A actualizar…'; }
      function reloadOnce(){
        if(reloading) return;
        reloading = true;
        window.location.reload();
      }
      navigator.serviceWorker.addEventListener('controllerchange',reloadOnce,{once:true});
      waiting.postMessage({type:'SKIP_WAITING'});
      setTimeout(function(){
        if(reloading) return;
        var active = navigator.serviceWorker.controller;
        if(active && versionInUse && active.scriptURL.indexOf('v=' + encodeURIComponent(versionInUse)) !== -1) reloadOnce();
        else if(button){ button.disabled = false; button.textContent = 'Tentar novamente'; }
      },4000);
    });
  }
  function observe(reg){
    registration = reg;
    if(reg.waiting) showIfUpdateWaiting();
    reg.addEventListener('updatefound',function(){
      var worker = reg.installing;
      if(!worker || worker === observingWorker) return;
      observingWorker = worker;
      worker.addEventListener('statechange',function(){
        if(worker.state === 'installed' && navigator.serviceWorker.controller){
          setTimeout(showIfUpdateWaiting,0);
        }
      });
    });
  }
  async function checkForUpdates(){
    var current = await latestVersion();
    if(current && current !== versionInUse){
      versionInUse = current;
      try{
        registration = await navigator.serviceWorker.register(scriptUrl(current),{scope:'/'});
        observe(registration);
      }catch(_e){}
    }
    if(registration){
      try{ await registration.update(); }catch(_e){}
      showIfUpdateWaiting();
    }
  }

  window.addEventListener('load',async function(){
    try{
      versionInUse = await latestVersion();
      var existing = await navigator.serviceWorker.getRegistration('/');
      if(versionInUse){
        registration = await navigator.serviceWorker.register(scriptUrl(versionInUse),{scope:'/'});
      }else if(existing && existing.active && existing.active.scriptURL.indexOf('/sw-curso.js') !== -1){
        registration = existing;
      }else if(!existing || navigator.onLine){
        registration = await navigator.serviceWorker.register(scriptUrl(null),{scope:'/'});
      }else{
        registration = existing;
      }
      if(registration) observe(registration);
      if(registration){ try{ await registration.update(); }catch(_e){} }
      showIfUpdateWaiting();
      window.addEventListener('online',checkForUpdates);
      document.addEventListener('visibilitychange',function(){
        if(document.visibilityState === 'visible') checkForUpdates();
      });
      setInterval(function(){ if(document.visibilityState === 'visible') checkForUpdates(); },5*60*1000);
    }catch(err){
      console.warn('Verificação de actualizações indisponível:',err);
    }
  });
})();