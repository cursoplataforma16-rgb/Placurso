/* ANNAN Playwright — capacidade permanente de navegação do ANNAN Online. */
(function(){
  'use strict';
  const ENDPOINT='/api/annan/playwright';
  const call=async(action,args={})=>{
    const r=await fetch(ENDPOINT,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({action,...args})});
    const data=await r.json().catch(()=>({}));
    if(!r.ok) throw new Error(data?.error||`Playwright HTTP ${r.status}`);
    return data;
  };
  window.ANNAN_PLAYWRIGHT={
    open:(url)=>call('open',{url}),
    text:(url)=>call('text',{url}),
    links:(url)=>call('links',{url}),
    click:(url,index)=>call('click',{url,index}),
    fill:(url,selector,value)=>call('fill',{url,selector,value}),
    screenshot:(url,fullPage=false)=>call('screenshot',{url,fullPage}),
    enabled:true,
    endpoint:ENDPOINT
  };
  if(window.ANNAN_ONLINE_JOURNAL?.recordTool){
    window.ANNAN_ONLINE_JOURNAL.recordTool({name:'playwright',version:'1',endpoint:ENDPOINT,actions:['open','text','links','click','fill','screenshot']});
  }
})();
