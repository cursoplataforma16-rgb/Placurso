/* ANNAN Creative Studio UI */
(function(){
'use strict';
function render(host){
 if(!host)return;
 host.innerHTML=`<section style="background:#171412;color:#eee7df;border:1px solid #3b332c;border-radius:16px;padding:16px;max-width:900px;margin:16px auto"><h2 style="margin:0 0 6px">ANNAN Creative Studio</h2><p style="color:#a9a096;margin:0 0 16px">Reels com gancho, narrativa, demonstração, voz e CTA — sem cenas de enchimento.</p><div style="display:grid;gap:10px"><textarea id="cs-prompt" style="min-height:110px;width:100%;box-sizing:border-box;background:#211d19;color:#eee7df;border:1px solid #4b4035;border-radius:10px;padding:12px" placeholder="Produto/tema, público específico, problema, oferta e objetivo do Reel..."></textarea><div style="display:grid;grid-template-columns:1fr 1fr;gap:8px"><label style="font-size:12px;color:#bcb3aa">Duração alvo<select id="cs-duration" style="display:block;width:100%;margin-top:5px;padding:10px;background:#211d19;color:#eee7df;border:1px solid #4b4035;border-radius:9px"><option value="25">25s — directo</option><option value="35" selected>35s — recomendado</option><option value="45">45s — storytelling</option><option value="60">60s — demonstração</option></select></label><label style="font-size:12px;color:#bcb3aa">Objectivo<select id="cs-goal" style="display:block;width:100%;margin-top:5px;padding:10px;background:#211d19;color:#eee7df;border:1px solid #4b4035;border-radius:9px"><option>Gerar interesse</option><option>Ensinar algo</option><option>Levar ao site</option><option>Gerar contacto</option><option>Vender</option></select></label></div><div style="display:flex;gap:8px;flex-wrap:wrap"><button id="cs-reel">🎯 Reel Pro</button><button id="cs-copy">✍️ Copy + roteiro</button><button id="cs-image">🖼️ Imagem</button><button id="cs-video">🎥 Vídeo preciso</button><button id="cs-voice">🎙️ Narração limpa</button></div><div id="cs-out" style="white-space:pre-wrap;overflow:auto;max-height:55vh;background:#211d19;border:1px solid #3b332c;border-radius:10px;padding:12px;min-height:80px">Pronto.</div></div></section>`;
 const p=host.querySelector('#cs-prompt'),out=host.querySelector('#cs-out'),duration=host.querySelector('#cs-duration'),goal=host.querySelector('#cs-goal');
 const run=async(fn)=>{out.textContent='ANNAN a analisar público, hook, ritmo, cenas, voz e CTA…';try{const r=await fn();out.textContent=JSON.stringify(r.result||r,null,2);return r}catch(e){out.textContent='Erro: '+e.message}};
 host.querySelector('#cs-reel').onclick=()=>run(()=>ANNAN_CREATIVE.reel(p.value+'\nObjectivo escolhido: '+goal.value,duration.value));
 host.querySelector('#cs-copy').onclick=()=>run(()=>ANNAN_CREATIVE.text('Cria uma campanha específica para: '+p.value+'\nObjectivo: '+goal.value+'\nEntregar: público, problema, desejo, 5 hooks concretos, copy curta, storytelling, prova, oferta, CTA, roteiro de Reel e 3 variações A/B. Evita generalidades.'));
 host.querySelector('#cs-image').onclick=()=>run(()=>ANNAN_CREATIVE.image(p.value,'1024x1024'));
 host.querySelector('#cs-video').onclick=()=>run(()=>ANNAN_CREATIVE.video(p.value,null,'runway',{duration:8}));
 host.querySelector('#cs-voice').onclick=()=>run(()=>ANNAN_CREATIVE.voice(p.value));
}
window.renderCreativeStudio=render;
function mount(){
 const sheet=document.querySelector('.ao-sheet');
 if(!sheet||sheet.querySelector('#ao-creative-open'))return;
 const b=document.createElement('button');b.id='ao-creative-open';b.textContent='🎨 Creative Studio';
 sheet.appendChild(b);
 b.onclick=()=>{
  let overlay=document.getElementById('ao-creative-overlay');
  if(!overlay){overlay=document.createElement('div');overlay.id='ao-creative-overlay';Object.assign(overlay.style,{position:'fixed',inset:'0',zIndex:'9999',overflow:'auto',background:'#0f0d0b',padding:'12px'});const close=document.createElement('button');close.textContent='← Voltar ao ANNAN';Object.assign(close.style,{padding:'10px 14px',margin:'4px',cursor:'pointer'});close.onclick=()=>overlay.remove();overlay.appendChild(close);const host=document.createElement('div');overlay.appendChild(host);document.body.appendChild(overlay);render(host);}else overlay.remove();
 };
}
new MutationObserver(mount).observe(document.documentElement,{childList:true,subtree:true});
setTimeout(mount,500);
})();
