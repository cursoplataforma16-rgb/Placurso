/* Recomendação adaptativa do ANNAN: o resultado do desafio pode tornar-se um pedido real de curso. */
(function(){
  'use strict';
  var instalado=false;
  function isHome(){ return location.pathname === '/cursos' && !new URLSearchParams(location.search).has('parte'); }
  function esc(v){ return String(v||'').replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];}); }
  function scoreFrom(text){
    var m=String(text||'').match(/(\d+)\s*(?:\/|de)\s*10/i);
    return m ? Math.max(0,Math.min(100,Number(m[1])*10)) : null;
  }
  function recomendacao(score){
    if(score!==null && score<60) return {horas:2,nivel:'básico',rotulo:'2 h · Básico',explica:'Volte aos fundamentos e pratique os passos essenciais.'};
    if(score!==null && score<90) return {horas:6,nivel:'intermédio',rotulo:'6 h · Intermédio',explica:'Consolide os fundamentos com exemplos e treino guiado.'};
    return {horas:14,nivel:'avançado',rotulo:'14 h · Avançado',explica:'Aprofunde a estratégia com exercícios progressivos e desafios.'};
  }
  function lerAluno(){
    try{
      var a=JSON.parse(localStorage.getItem('ens_aluno')||'null');
      return a&&a.id&&a.token?a:null;
    }catch(_e){return null;}
  }
  function install(){
    if(!isHome() || instalado) return;
    instalado=true;
    var style=document.createElement('style');
    style.textContent='.pch-course-reco{display:none;margin-top:14px;padding:16px;border-radius:15px;background:#14284B;color:#fff}.pch-course-reco.show{display:block}.pch-course-reco h3{margin:0 0 6px;font-size:17px}.pch-course-reco p{margin:0 0 12px;color:rgba(255,255,255,.82);font-size:13px;line-height:1.5}.pch-course-reco label{display:block;font-size:12px;font-weight:800;margin:12px 0 6px}.pch-course-reco input{display:block;width:100%;min-height:44px;padding:10px 12px;border-radius:10px;border:1px solid rgba(255,255,255,.3);background:#fff;color:#14284B;font-size:14px;box-sizing:border-box}.pch-course-levels{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}.pch-course-level{padding:11px;border-radius:11px;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.16)}.pch-course-level strong{display:block;font-size:13px}.pch-course-level small{display:block;margin-top:4px;color:rgba(255,255,255,.7);line-height:1.4}.pch-course-request{margin-top:12px;width:100%;min-height:46px;border:0;border-radius:10px;background:#2AA39B;color:#062F35;font-weight:900;cursor:pointer}.pch-course-request:disabled{opacity:.65;cursor:wait}.pch-course-status{margin-top:10px;padding:12px;border-radius:10px;background:rgba(255,255,255,.1);font-size:13px;line-height:1.5}.pch-course-status a{color:#71D3C9;font-weight:800}@media(max-width:700px){.pch-course-levels{grid-template-columns:1fr}}';
    document.head.appendChild(style);
    var obs=new MutationObserver(bind);
    obs.observe(document.body,{childList:true,subtree:true});
    bind();
    function bind(){
      var results=document.getElementById('pchResults');
      if(!results || results.dataset.recoBound==='1') return;
      results.dataset.recoBound='1';
      var box=document.createElement('section');
      box.className='pch-course-reco';
      box.innerHTML='<h3 id="pchRecoTitle">Transforme o resultado num plano de treino</h3><p id="pchRecoText">O ANNAN adapta a duração ao seu resultado. O tema pode ser testes psicotécnicos, xadrez, enigmas ou outro assunto que escrever.</p><div class="pch-course-levels"><div class="pch-course-level"><strong>2 h · Básico</strong><small>Fundamentos essenciais para começar.</small></div><div class="pch-course-level"><strong>6 h · Intermédio</strong><small>Prática guiada e consolidação.</small></div><div class="pch-course-level"><strong>14 h · Avançado</strong><small>Treino aprofundado e desafios.</small></div></div><label for="pchRecoTopic">Que tema quer aprender?</label><input id="pchRecoTopic" maxlength="120" value="Testes psicotécnicos e raciocínio lógico" placeholder="Ex.: xadrez, enigmas, matemática"><div id="pchRecoDuration" class="pch-course-status"></div><button class="pch-course-request" type="button" id="pchRecoRequest">Pedir curso personalizado ao ANNAN</button><div class="pch-course-status" id="pchRecoStatus" hidden aria-live="polite"></div>';
      results.parentNode.insertBefore(box,results.nextSibling);
      var button=box.querySelector('#pchRecoRequest');
      var input=box.querySelector('#pchRecoTopic');
      var duration=box.querySelector('#pchRecoDuration');
      var status=box.querySelector('#pchRecoStatus');
      function update(){
        var hidden=results.hidden || getComputedStyle(results).display==='none' || !results.textContent.trim();
        box.classList.toggle('show',!hidden);
        if(hidden) return;
        var score=scoreFrom(results.textContent);
        var pick=recomendacao(score);
        duration.textContent='Recomendação: '+pick.rotulo+'. '+pick.explica+' Resultado do desafio: '+(score===null?'não identificado':(score/10).toFixed(0)+'/10')+'.';
      }
      new MutationObserver(update).observe(results,{attributes:true,childList:true,subtree:true,characterData:true});
      button.addEventListener('click',async function(){
        var topic=String(input.value||'').trim().replace(/\s+/g,' ').slice(0,120);
        if(topic.length<3){status.hidden=false;status.textContent='Escreva um tema com pelo menos 3 caracteres.';return;}
        var score=scoreFrom(results.textContent);
        var pick=recomendacao(score);
        var pedido='Quero aprender '+topic+'. Curso de '+pick.horas+' horas, nível '+pick.nivel+'. Adapte o conteúdo ao resultado '+(score===null?'não identificado':(score/10).toFixed(0)+'/10')+'. Ensine os fundamentos, mostre exemplos resolvidos, proponha exercícios graduais e termine com uma prova de prática.';
        status.hidden=false;
        status.textContent='A preparar o pedido…';
        button.disabled=true;
        button.textContent='A enviar…';
        try{
          var aluno=lerAluno();
          var temSessao=false;
          try{
            if(typeof sb!=='undefined' && sb.auth){var sess=await sb.auth.getSession();temSessao=!!(sess&&sess.data&&sess.data.session);}
          }catch(_e){}
          if(!aluno&&!temSessao){
            try{localStorage.setItem('ens_curso_sugerido',pedido);}catch(_e){}
            status.innerHTML='Para guardar este curso na sua conta, crie ou abra a sua conta de aluno. O pedido ficou preenchido para confirmar na área de cursos. <p><a href="/cursos?aprender=1">Abrir a minha conta de aluno</a></p>';
            button.disabled=false;
            button.textContent='Pedir depois de entrar';
            return;
          }
          var body={acao:'curso_pedir',pedido:pedido};
          if(aluno){body.id=aluno.id;body.token=aluno.token;}
          if(aluno&&aluno.telefone) body.telefone=String(aluno.telefone).replace(/\D/g,'').slice(-9);
          var result=await sb.functions.invoke('annan-ensino',{body:body});
          var data=result&&result.data||{};
          if(result&&result.error) throw new Error(data.nota||'Não foi possível contactar o ANNAN. Tente novamente.');
          if(!(data.ok||data.estado||data.curso_id)) throw new Error(data.nota||data.erro||'O pedido não foi confirmado. Tente novamente.');
          try{localStorage.setItem('ens_curso_pedido',data.curso_id||'');localStorage.removeItem('ens_curso_sugerido');}catch(_e){}
          status.innerHTML='Pedido registado'+(data.titulo?': <strong>'+esc(data.titulo)+'</strong>':'')+'. O curso fica associado à sua conta de aluno. '+esc(data.nota||'Abra a área do aluno para acompanhar a preparação.')+' <p><a href="/cursos?aprender=1">Ver a minha área de aluno</a></p>';
          if(window.medirEvento) medirEvento('desafio_curso_pedido');
          button.textContent='Curso pedido';
          button.disabled=true;
        }catch(error){
          status.textContent=String(error&&error.message||'Falha ao pedir o curso. Tente novamente.');
          button.disabled=false;
          button.textContent='Tentar novamente';
        }
      });
      update();
    }
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',install); else install();
})();