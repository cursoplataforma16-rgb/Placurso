/* ANNAN Creative Studio — geração de texto, imagem, vídeo e voz. */
(function(){
  'use strict';
  const API='https://ebdrrsrvjsdjthatfbcd.supabase.co/functions/v1/annan-media-ai';
  const journal=(type,payload)=>window.ANNAN_ONLINE_JOURNAL?.record(type,payload).catch(()=>{});
  window.ANNAN_CREATIVE={
    async call(body){
      const started=new Date().toISOString();
      await journal('tool.called',{tool:'annan-media-ai',action:body.action,provider:body.provider||null,input:body.prompt||body.text||null,started_at:started});
      try{
        const headers={'Content-Type':'application/json'};
        try{
          if(typeof sb!=='undefined'&&sb&&sb.auth&&typeof sb.auth.getSession==='function'){
            const sess=await sb.auth.getSession();
            if(sess&&sess.data&&sess.data.session&&sess.data.session.access_token) headers.Authorization='Bearer '+sess.data.session.access_token;
          }
        }catch(_authError){}
        const r=await fetch(API,{method:'POST',headers,body:JSON.stringify(body)});
        const j=await r.json().catch(()=>({}));
        if(!r.ok||j.ok===false) throw new Error(j.error||('Creative Studio HTTP '+r.status));
        await journal('tool.result',{tool:'annan-media-ai',action:body.action,provider:body.provider||null,output:j,started_at:started,completed_at:new Date().toISOString()});
        return j;
      }catch(error){await journal('error.created',{source:'annan-media-ai',action:body.action,message:String(error?.message||error)});throw error;}
    },
    async text(prompt,provider){return this.call({action:'text',prompt,provider:provider||'openai'});},
    async image(prompt,size){return this.call({action:'image',prompt,size:size||'1024x1024'});},
    async video(prompt,image_url,provider,options){
      const o=options||{};
      const precision=[
        'ANNAN SHORT VIDEO ENGINE PRO v4. Create a production-ready vertical 9:16 short-form video.',
        'Objective: stop the scroll, communicate one specific idea, prove it visually, and end with one action.',
        'First 1.2 seconds: immediate visual hook. Never start with logo, greeting, title card, empty room or slow establishing shot.',
        'Use a tight visual sequence: hook, problem/desire, concrete demonstration, key explanation, payoff, CTA. Every shot must advance the message.',
        'Use close-up, medium, detail, over-shoulder, screen/demo, before-after or graphic shots when relevant. Avoid generic AI scenery and repeated camera angles.',
        'Maintain factual accuracy and subject continuity. Never invent prices, features, statistics, clients, testimonials, guarantees, locations or results.',
        'On-screen text: maximum 5 words per card, high contrast, large enough for a phone, placed inside safe margins. Do not duplicate the narration word-for-word.',
        'Editing: purposeful cuts every 1-3 seconds when the content permits; use movement, visual change or information gain to maintain attention without chaotic effects.',
        'Audio: narration is the primary track. Music must stay clearly below speech. No clipping, distortion, excessive reverb or robotic delivery.',
        'Finish with exactly one CTA, visually obvious and specific. No multiple competing calls to action.'
      ].join(' ');
      return this.call({action:'video',prompt:precision+'\n'+prompt,image_url,provider:provider||'runway',ratio:'720:1280',duration:Number(o.duration)||20});
    },
    async reel(prompt,provider,options){
      const o=options||{};
      const duration=Math.min(35,Math.max(15,Number(o.duration)||25));
      const sceneCount=duration<=20?6:8;
      const brief=[
        'ANNAN REEL ENGINE PRO v4 — roteiro de conversão e retenção para vídeo vertical.',
        'Contexto específico: '+prompt,
        'Idioma: português de Angola. Não traduzir nem misturar idiomas.',
        'Duração alvo: '+duration+' segundos. Gerar exactamente '+sceneCount+' cenas, com progressão visual real.',
        'Estrutura obrigatória: 1) hook imediato; 2) problema ou curiosidade; 3) demonstração concreta; 4) explicação/objectivo; 5) recompensa ou descoberta; 6) resolução; '+(sceneCount>6?'7) reforço da utilidade; 8) CTA único.':'7) CTA único.'),
        'O conteúdo deve ser específico ao assunto fornecido. Se for produto/serviço, mostrar o benefício real e não fazer publicidade genérica. Se for educativo, mostrar uma pergunta, resposta ou transformação concreta.',
        'A primeira frase deve criar curiosidade sem clickbait falso. Não usar frases vazias como “você não vai acreditar”, “mude sua vida” ou “o segredo que ninguém conta” sem prova no conteúdo.',
        'Cada cena deve ter uma acção visual clara: pessoa, objecto, interface, demonstração, comparação, gráfico ou elemento de jogo. Nunca pedir uma imagem que apenas “pareça bonita”.',
        'Narração: 8-12 palavras por cena; frases curtas; dicção simples; voz confiante, humana, precisa e objectiva; sem teatralidade, gritos ou exagero. A narração deve acrescentar informação ao texto do ecrã.',
        'Texto no ecrã: 2-5 palavras por cena, complementar à voz, legível em telemóvel e dentro das margens seguras.',
        'Variar enquadramentos e movimentos, mas sem efeitos gratuitos. Cada corte deve aumentar compreensão, curiosidade ou recompensa.',
        'CTA único no final, relacionado directamente ao objectivo do conteúdo. Não juntar “seguir + comprar + partilhar + comentar + descarregar” no mesmo CTA.',
        'Não inventar preços, descontos, estatísticas, resultados, testemunhos, garantias, características ou factos ausentes no contexto.',
        'A marca indicada no contexto é a única marca principal. Nunca misturar Dionuel Alfaiataria com Plataforma Curso.',
        'Formato EXATO: Título: ...; depois Cena 1 até Cena '+sceneCount+' no formato “Cena N (Xs) | VISUAL: ... | TEXTO: ... | NARRAÇÃO: ...”; depois “CTA: ...”. Sem explicações adicionais.'
      ].join('\n');
      return this.call({action:'text',prompt:brief,provider:provider||'auto'});
    },
    async videoStatus(task_id){return this.call({action:'video_status',task_id});},
    async voice(text,voice_id){
      const narration='Read exactly the supplied text. Natural human delivery in Portuguese (Angola). Precise diction, crisp consonants, objective intonation, confident conversational tone, medium-fast pace, controlled short pauses, no filler, no theatrical exaggeration, no shouting, no whispering, no robotic cadence. Keep every word intelligible and preserve the intended emphasis. Do not add, remove or paraphrase words.';
      return this.call({action:'voice',text:narration+'\nTEXT:\n'+text,voice_id});
    }
  };
})();
