const CACHE_VERSION = (new URL(self.location.href).searchParams.get('v') || 'bootstrap').replace(/[^A-Za-z0-9._-]/g,'').slice(0,64);
const CACHE_NAME = 'plataforma-curso-' + CACHE_VERSION;
const APP_SHELL = ['/cursos','/manifest-curso.json','/curso-icon-192.png','/curso-icon-512.png','/home-curso-simples.js','/pwa-update.js'];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => Promise.all(APP_SHELL.map(url => cache.add(url).catch(() => null)))));
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('message', event => {
  if(event.data && event.data.type === 'SKIP_WAITING') self.skipWaiting();
});

self.addEventListener('fetch', event => {
  const request = event.request;
  if(request.method !== 'GET') return;
  const url = new URL(request.url);
  if(url.origin !== self.location.origin) return;

  // O manifesto de versão nunca é servido a partir de uma cópia antiga.
  if(url.pathname === '/pwa-version.json'){
    event.respondWith(fetch(request,{cache:'no-store'}));
    return;
  }

  // HTML: rede primeiro para garantir que uma nova publicação chega ao aluno.
  if(request.mode === 'navigate' || request.destination === 'document') {
    event.respondWith(
      fetch(request, {cache:'no-store'}).then(response => {
        const copy = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(request, copy)).catch(()=>{});
        return response;
      }).catch(() => caches.match(request).then(cached => cached || caches.match('/cursos')))
    );
    return;
  }

  // JavaScript e CSS: rede primeiro para que a app receba correcções recentes,
  // mantendo uma cópia de reserva quando o aluno está offline.
  if(request.destination === 'script' || request.destination === 'style'){
    event.respondWith(
      fetch(request,{cache:'no-store'}).then(response => {
        if(response && response.ok){
          const copy = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(request,copy)).catch(()=>{});
        }
        return response;
      }).catch(() => caches.match(request))
    );
    return;
  }

  // Imagens e outros recursos: cache rápido com a rede como reserva.
  event.respondWith(
    caches.match(request).then(cached => cached || fetch(request).then(response => {
      if(response && response.ok){
        const copy = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(request,copy)).catch(()=>{});
      }
      return response;
    }).catch(() => cached))
  );
});
