import { chromium as playwright } from "playwright-core";
import chromium from "@sparticuz/chromium";
import { randomUUID } from "node:crypto";
import { rm } from "node:fs/promises";

const MAX_TEXT = 12000;
const MAX_LINKS = 200;
const TIMEOUT = 20000;

function isPublicHttpUrl(value) {
  try {
    const u = new URL(value);
    if (!/^https?:$/.test(u.protocol)) return false;
    const h = u.hostname.toLowerCase();
    if (h === "localhost" || h.endsWith(".local") || h === "::1") return false;
    if (/^(10|127)\./.test(h) || /^192\.168\./.test(h) || /^169\.254\./.test(h)) return false;
    if (/^172\.(1[6-9]|2\d|3[0-1])\./.test(h)) return false;
    return true;
  } catch { return false; }
}

function json(data, status = 200) {
  return Response.json(data, { status });
}

function normaliseActions(body) {
  if (Array.isArray(body?.actions) && body.actions.length) return body.actions.slice(0, 20);
  return [{ action: body?.action || "open", selector: body?.selector, value: body?.value }];
}

function validateAction(step) {
  const action = step?.action || "open";
  if (!["open", "text", "links", "click", "fill", "screenshot", "wait"].includes(action)) {
    throw new Error(`Unsupported action: ${action}`);
  }
  if ((action === "click" || action === "fill") && typeof step.selector !== "string") {
    throw new Error(`selector is required for ${action}`);
  }
  return action;
}

export default async (req) => {
  if (req.method !== "POST") return json({ ok: false, error: "POST only" }, 405);

  const expected = Netlify.env.get("ANNAN_PLAYWRIGHT_KEY");
  if (expected && req.headers.get("x-annan-playwright-key") !== expected) {
    return json({ ok: false, error: "Unauthorized" }, 401);
  }

  let body;
  try { body = await req.json(); } catch { return json({ ok: false, error: "Invalid JSON" }, 400); }

  const url = body?.url;
  if (!url || !isPublicHttpUrl(url)) return json({ ok: false, error: "A public http/https URL is required" }, 400);

  const steps = normaliseActions(body);
  try { steps.forEach(validateAction); } catch (error) {
    return json({ ok: false, error: String(error?.message || error) }, 400);
  }

  const userDataDir = `/tmp/annan-pw-${randomUUID()}`;
  let browser;
  try {
    browser = await playwright.launch({
      args: [...chromium.args, `--user-data-dir=${userDataDir}`],
      executablePath: await chromium.executablePath(),
      headless: true,
    });
    const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
    const page = await context.newPage();
    page.setDefaultTimeout(TIMEOUT);

    const consoleErrors = [];
    const failedRequests = [];
    page.on("console", (msg) => {
      if (msg.type() === "error") consoleErrors.push(msg.text().slice(0, 500));
    });
    page.on("requestfailed", (request) => {
      failedRequests.push({ url: request.url(), error: request.failure()?.errorText || "failed" });
    });

    const outputs = [];
    let screenshot = null;

    for (const step of steps) {
      const action = validateAction(step);
      if (action === "open") {
        await page.goto(url, { waitUntil: "domcontentloaded", timeout: TIMEOUT });
      } else if (action === "click") {
        await page.locator(step.selector).first().click();
        await page.waitForLoadState("domcontentloaded").catch(() => {});
      } else if (action === "fill") {
        await page.locator(step.selector).first().fill(String(step.value ?? ""));
      } else if (action === "wait") {
        await page.waitForTimeout(Math.min(Math.max(Number(step.ms) || 500, 0), 10000));
      } else if (action === "text") {
        outputs.push({ action, text: (await page.locator("body").innerText()).slice(0, MAX_TEXT) });
      } else if (action === "links") {
        outputs.push({
          action,
          links: await page.locator("a").evaluateAll((els) => els.slice(0, MAX_LINKS).map((a) => ({ text: (a.textContent || "").trim(), href: a.href })).filter((x) => x.href)),
        });
      } else if (action === "screenshot") {
        screenshot = (await page.screenshot({ type: "jpeg", quality: 65 })).toString("base64");
      }
    }

    const result = {
      ok: true,
      actions: steps.map((s) => s.action || "open"),
      url: page.url(),
      title: await page.title(),
      outputs,
      diagnostics: {
        consoleErrors: consoleErrors.slice(0, 30),
        failedRequests: failedRequests.slice(0, 30),
      },
    };
    if (screenshot) result.screenshot = screenshot;
    if (!outputs.length && steps.length === 1 && ["open", "click", "fill"].includes(steps[0].action || "open")) {
      result.text = (await page.locator("body").innerText()).slice(0, MAX_TEXT);
    }
    return json(result);
  } catch (error) {
    return json({ ok: false, error: String(error?.message || error) }, 500);
  } finally {
    try { await browser?.close(); } catch {}
    await rm(userDataDir, { recursive: true, force: true }).catch(() => {});
  }
};

export const config = {
  path: "/api/annan/playwright",
};
