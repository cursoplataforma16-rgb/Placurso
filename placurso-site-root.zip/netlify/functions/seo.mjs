// Páginas para os motores de pesquisa (Google, Bing) e para pré-visualizações nas redes:
//   /sitemap.xml       -> lista de todas as páginas públicas (loja + cada produto)
//   /p/<nome>--<id>    -> página própria de cada produto, com título, descrição, foto, preço e botão "Comprar já"
// Lê só dados públicos (chave pública, a mesma da loja).
const SB = 'https://oettkaytgkkbrjoaeiqu.supabase.co';
const ANON = 'sb_publishable_xCkqK8v-DGWq9qnfYSHfPQ_HW9dno1C';
const SITE = 'https://dionuel.netlify.app';
const SITE_CURSO = 'https://placurso.netlify.app'; // marcas separadas: a Plataforma Curso só vive neste endereço
const ehCurso = u => /^(www\.)?(plataforma-?cu(rso)?|placurso)(-[a-z0-9]+)?\./i.test(new URL(u).hostname);
const DIGITAIS = ['ebook', 'combo'];
const esc = s => String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const slug = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 70) || 'produto';
const kz = n => String(Math.round(Number(n) || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ' Kz';
export const urlProduto = p => `${DIGITAIS.includes(p.tipo) ? SITE_CURSO : SITE}/p/${slug(p.nome)}--${p.id}`;

async function produtos(filtro = '') {
  const r = await fetch(`${SB}/rest/v1/produtos?select=id,nome,descricao,tipo,preco,preco_promocional,promocao_fim,imagem_url,imagem_social,codigo,moeda,ativo,criado_em&ativo=eq.true${filtro}&order=criado_em.desc&limit=500`, { headers: { apikey: ANON, Authorization: 'Bearer ' + ANON } });
  if (!r.ok) return [];
  return await r.json();
}
function precoAtual(p) {
  const promo = p.preco_promocional && (!p.promocao_fim || new Date(p.promocao_fim).getTime() > Date.now());
  return promo ? Number(p.preco_promocional) : Number(p.preco || 0);
}

async function sitemap(curso = false) {
  const lista = (await produtos()).filter(p => DIGITAIS.includes(p.tipo) === curso);
  const hoje = new Date().toISOString().slice(0, 10);
  const urls = (curso ? [`${SITE_CURSO}/cursos`] : [`${SITE}/`, `${SITE}/alfaiataria`]).map(u => `<url><loc>${u}</loc><lastmod>${hoje}</lastmod><changefreq>daily</changefreq><priority>0.9</priority></url>`);
  for (const p of lista) urls.push(`<url><loc>${esc(urlProduto(p))}</loc><lastmod>${String(p.criado_em || hoje).slice(0, 10)}</lastmod><changefreq>weekly</changefreq><priority>0.8</priority>${p.imagem_url && /\.(png|jpe?g|webp)(\?|$)/i.test(p.imagem_url) ? `<image:image><image:loc>${esc(p.imagem_url)}</image:loc></image:image>` : ''}</url>`);
  return new Response(`<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">\n${urls.join('\n')}\n</urlset>`, { headers: { 'Content-Type': 'application/xml; charset=utf-8', 'Cache-Control': 'public, max-age=3600' } });
}

// Ponte das redes (pedido do CEO, 19/10/2026): cada post mostra um código curto (ex.: K7H) e o endereço curto <site>/p/K7H.
// /p/<código> leva direto ao produto; /p/GRATIS às aulas grátis; /ver é a página do "link na bio" com os produtos dos posts recentes.
async function porCodigo(codigo, reqUrl) {
  const c = String(codigo || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  const curso = ehCurso(reqUrl);
  if (c === 'GRATIS' || c === 'GRA' || c === 'AULAS') return Response.redirect(`${SITE_CURSO}/cursos?aprender=1&utm_source=codigo&utm_campaign=gratis`, 302);
  const [p] = await produtos(`&codigo=ilike.${encodeURIComponent(c)}`);
  if (!p) return Response.redirect(`${curso ? SITE_CURSO : SITE}/ver?nao=${encodeURIComponent(c)}`, 302);
  const digital = DIGITAIS.includes(p.tipo);
  if (digital) return await paginaRapida(p, c);
  return Response.redirect(`${SITE}/?produto=${p.id}&utm_source=codigo&utm_campaign=${c}`, 302);
}

// Página rápida do produto digital (25/10/2026): quem vem das redes pelo código abria a loja inteira (1,8 MB, 7 s num telemóvel bom)
// e 69% saía em menos de 10 s sem ver nada. Agora vê logo, em ~20 KB: o que é, o que recebe, o preço em dólares (e em kwanzas)
// e "Comprar já", que abre a loja já no pagamento (?comprar=1).
const TIPOS = {
  FERRAMENTA: { rot: 'Ferramenta digital', recebe: ['Uma ferramenta pronta a usar: preenche os seus dados e ela faz as contas por si', 'Abre no telemóvel e no computador; depois de guardada funciona sem internet', 'Uso ilimitado, para sempre'] },
  RESUMO: { rot: 'Resumo digital', recebe: ['As ideias principais do tema, para ler em poucos minutos', 'Abre no telemóvel logo depois do pagamento', 'Acesso ilimitado: leia quantas vezes quiser'] },
  KIT: { rot: 'Kit digital', recebe: ['Várias ferramentas e modelos prontos, tudo junto', 'Copie, preencha e use no mesmo dia', 'Acesso ilimitado no telemóvel'] },
  LIVRO: { rot: 'Livro-guia digital', recebe: ['Um livro-guia prático, passo a passo, que abre no telemóvel', 'Acesso ilimitado: não se estraga, não se perde, leia quantas vezes quiser', 'Recebe logo depois do pagamento'] }
};
const tipoDe = p => { if (p.tipo === 'combo') return 'KIT'; const t = `${p.nome || ''}`.toLowerCase(); if (/calculadora|planeador|planilha|ferramenta|gerador|simulador|controlo|offline|painel/.test(t)) return 'FERRAMENTA'; if (/resumo/.test(t)) return 'RESUMO'; if (/\bkit\b|modelos?\b|pack/.test(t)) return 'KIT'; return 'LIVRO'; };
async function taxaUsd() {
  try { const r = await fetch(`${SB}/functions/v1/pagamentos`, { method: 'POST', headers: { 'Content-Type': 'application/json', apikey: ANON, Authorization: 'Bearer ' + ANON }, body: JSON.stringify({ acao: 'config' }), signal: AbortSignal.timeout(2500) }); const j = await r.json(); return j && j.usd && Number(j.usd.kz_por_usd) > 0 ? j.usd : null; } catch (_e) { return null; }
}
const usdDe = (kzv, u) => (u && kzv > 0) ? Math.max(1, Math.ceil(kzv / Number(u.kz_por_usd) * (1 + Number(u.margem || 0)) * 100) / 100) : null;
async function paginaRapida(p, c) {
  const u = await taxaUsd(); const v = precoAtual(p); const usd = usdDe(v, u); const T = TIPOS[tipoDe(p)];
  const img = /^https?:/.test(p.imagem_social || '') ? p.imagem_social : (p.imagem_url || '');
  const base = `${SITE_CURSO}/cursos?produto=${p.id}&utm_source=codigo&utm_campaign=${encodeURIComponent(c)}`;
  const desc = String(p.descricao || '').replace(/\r/g, '').trim(); const curta = desc.length > 900 ? desc.slice(0, 900).replace(/\s+\S*$/, '') + '…' : desc;
  const precoGrande = usd ? `US$ ${usd.toFixed(2).replace('.', ',')}` : kz(v);
  const precoPeq = usd ? `ou ${kz(v)}` : '';
  const html = `<!doctype html><html lang="pt"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(p.nome)} | Plataforma Curso</title><meta name="description" content="${esc(T.rot + ': ' + desc.replace(/\s+/g, ' ').slice(0, 140))}">
<meta property="og:site_name" content="Plataforma Curso"><meta property="og:type" content="product"><meta property="og:title" content="${esc(p.nome)}"><meta property="og:description" content="${esc(T.rot + ' · ' + precoGrande)}">${img ? `<meta property="og:image" content="${esc(img)}">` : ''}<meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="/curso-icon-192.png"><meta name="theme-color" content="#14284B">${img ? `<link rel="preload" as="image" href="${esc(img)}">` : ''}
<style>*{box-sizing:border-box}body{margin:0;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:#FBF9F2;color:#14284B;line-height:1.5}main{max-width:560px;margin:0 auto;padding:14px 16px 110px}
.top{display:flex;align-items:center;gap:10px;font-weight:800;letter-spacing:.14em;font-size:13px;color:#14284B;text-decoration:none}.top img{width:32px;height:32px;border-radius:8px}
.foto{width:100%;aspect-ratio:4/5;object-fit:cover;border-radius:16px;background:#ece6d6;display:block;margin:14px 0 12px}
.tipo{display:inline-block;background:#1B8A83;color:#fff;font-size:12px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;padding:5px 10px;border-radius:999px}
h1{font-size:24px;line-height:1.2;margin:10px 0 8px}.preco{display:flex;align-items:baseline;gap:10px;flex-wrap:wrap}.preco b{font-size:30px}.preco span{font-size:15px;color:#55657C}
.btn{display:block;text-align:center;background:#1B8A83;color:#fff;font-weight:800;font-size:18px;padding:16px;border-radius:14px;text-decoration:none;margin:14px 0 8px;min-height:52px}
.sec{background:#fff;border:1px solid #e6e0d0;border-radius:14px;padding:12px 14px;margin:12px 0}.sec h2{font-size:13px;letter-spacing:.08em;text-transform:uppercase;color:#1B8A83;margin:0 0 6px}
.sec li{margin:6px 0}.sec ul{padding-left:18px;margin:0}.desc{white-space:pre-line;font-size:15px;color:#2d3f5c}
.paga{font-size:13.5px;color:#55657C}.fixo{position:fixed;left:0;right:0;bottom:0;background:#FBF9F2;border-top:1px solid #e6e0d0;padding:10px 16px calc(10px + env(safe-area-inset-bottom));display:flex;gap:8px;max-width:560px;margin:0 auto}
.fixo a{flex:1;text-align:center;padding:14px 10px;border-radius:12px;font-weight:800;text-decoration:none;min-height:48px}.fixo .c{background:#1B8A83;color:#fff}.fixo .d{background:#fff;border:1.5px solid #14284B;color:#14284B;flex:.7}
.peq{font-size:13px;color:#55657C;text-align:center}</style></head><body><main>
<a class="top" href="${SITE_CURSO}/cursos?utm_source=codigo"><img src="/curso-logo.png" alt="">PLATAFORMA CURSO</a>
${img ? `<img class="foto" src="${esc(img)}" alt="${esc(p.nome)}" fetchpriority="high">` : ''}
<span class="tipo">${esc(T.rot)}</span>
<h1>${esc(p.nome)}</h1>
<div class="preco"><b>${esc(precoGrande)}</b><span>${esc(precoPeq)}</span></div>
<a class="btn" id="comprar" href="${esc(base)}&comprar=1">Comprar já</a>
<p class="peq">Paga em poucos toques e recebe logo no telemóvel.</p>
<div class="sec"><h2>O que recebe</h2><ul>${T.recebe.map(x => `<li>${esc(x)}</li>`).join('')}</ul></div>
${curta ? `<div class="sec"><h2>Em detalhe</h2><div class="desc">${esc(curta)}</div></div>` : ''}
<div class="sec"><h2>Como pagar</h2><div class="paga">Em dólares (USDT pela Bybit Pay) ou em kwanzas (Multicaixa Express ou transferência). Depois da confirmação do pagamento, o acesso abre na hora e fica guardado na sua biblioteca.</div></div>
<p class="peq">Código ${esc(p.codigo || c)} · <a href="${SITE_CURSO}/ver">ver outros produtos</a></p>
</main>
<div class="fixo"><a class="d" href="${SITE_CURSO}/cursos?falar=1&utm_source=codigo">Tenho dúvidas</a><a class="c" href="${esc(base)}&comprar=1">Comprar · ${esc(precoGrande)}</a></div>
<script>(function(){try{var k='pc_sid',s=localStorage.getItem(k);if(!s){s=Math.random().toString(36).slice(2)+Date.now().toString(36);localStorage.setItem(k,s)}try{sessionStorage.setItem('pc_origem','codigo')}catch(e){}
var t0=Date.now(),ua=navigator.userAgent,d=/iPad|Tablet/i.test(ua)?'tablet':/Mobi|Android|iPhone/i.test(ua)?'telemovel':'computador',so=/Android/i.test(ua)?'android':/iPhone|iPad/i.test(ua)?'ios':/Windows/i.test(ua)?'windows':'outro',
U='${SB}/rest/v1/rpc/site_ping?apikey=${ANON}';function env(seg,ev,fim){var b=JSON.stringify({p_sid:s,p_marca:'curso',p_pagina:'/p',p_origem:'codigo',p_campanha:${JSON.stringify(c)},p_dispositivo:d,p_sistema:so,p_app:false,p_segundos:Math.min(60,Math.round(seg)),p_nova_pagina:!seg&&!ev,p_evento:ev||null});
try{if(fim&&navigator.sendBeacon){navigator.sendBeacon(U,new Blob([b],{type:'application/json'}));return}fetch(U,{method:'POST',headers:{'Content-Type':'application/json',apikey:'${ANON}'},body:b,keepalive:true})}catch(e){}}
env(0);document.addEventListener('visibilitychange',function(){if(document.visibilityState==='hidden'){env((Date.now()-t0)/1000,null,true);t0=Date.now()}});
[].forEach.call(document.querySelectorAll('a[href*="comprar=1"]'),function(a){a.addEventListener('click',function(){env((Date.now()-t0)/1000,'iniciou_compra',true);t0=Date.now()})});}catch(e){}})();</script>
</body></html>`;
  return new Response(html, { headers: { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'public, max-age=300' } });
}

async function bio(req) {
  const u = new URL(req.url); const curso = ehCurso(req.url); const base = curso ? SITE_CURSO : SITE;
  const nao = (u.searchParams.get('nao') || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6);
  const todos = (await produtos()).filter(p => DIGITAIS.includes(p.tipo) === curso && p.codigo);
  // os dos posts recentes vêm primeiro (é o que a pessoa acabou de ver)
  let recentes = [];
  try { const r = await fetch(`${SB}/rest/v1/rpc/redes_produtos_recentes`, { method: 'POST', headers: { apikey: ANON, Authorization: 'Bearer ' + ANON, 'Content-Type': 'application/json' }, body: JSON.stringify({ p_curso: curso }) }); if (r.ok) recentes = (await r.json()) || []; } catch (_e) { /* */ }
  const ordem = new Map(recentes.map((id, i) => [id, i]));
  const lista = todos.sort((a, b) => (ordem.has(a.id) ? ordem.get(a.id) : 999) - (ordem.has(b.id) ? ordem.get(b.id) : 999)).slice(0, 40);
  const cor = curso ? { bg: '#FBF9F2', tx: '#14284B', ac: '#1B8A83', ca: '#ffffff', bd: '#E3DED0' } : { bg: '#171412', tx: '#efe6da', ac: '#b8935a', ca: '#221e1a', bd: '#3a332c' };
  const nome = curso ? 'Plataforma Curso' : 'Dionuel Alfaiataria';
  const card = p => { const img = (curso && /^https?:/.test(p.imagem_social || '')) ? p.imagem_social : p.imagem_url; return `<a class="c" href="${base}/p/${esc(p.codigo)}"><span class="im"${img ? ` style="background-image:url('${esc(img)}')"` : ''}></span><span class="tx"><b>${esc(p.nome)}</b><small>Código ${esc(p.codigo)}${ordem.has(p.id) ? ' · nos posts de agora' : ''}</small></span><span class="go">Abrir</span></a>`; };
  const html = `<!doctype html><html lang="pt"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>${nome} · tudo num só link</title><meta name="description" content="Encontre o que viu nas redes: escreva o código do post ou toque no produto.">
<link rel="icon" href="${curso ? '/curso-icon-192.png' : '/icon-192.png'}"><meta name="theme-color" content="${cor.tx}">
<meta property="og:title" content="${nome}"><meta property="og:image" content="${curso ? SITE_CURSO + '/curso-og.png' : SITE + '/icon-512.png'}">
<style>*{box-sizing:border-box}body{margin:0;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:${cor.bg};color:${cor.tx}}main{max-width:560px;margin:0 auto;padding:22px 16px 50px}
h1{font-size:22px;margin:6px 0 4px}p{margin:4px 0 14px;opacity:.85;font-size:15px}.cod{display:flex;gap:8px;margin:12px 0 8px}.cod input{flex:1;min-width:0;font-size:22px;letter-spacing:.2em;text-transform:uppercase;padding:12px 14px;border:2px solid ${cor.ac};border-radius:12px;background:${cor.ca};color:${cor.tx}}
.cod button,.big{border:0;border-radius:12px;background:${cor.ac};color:#fff;font-weight:700;font-size:16px;padding:0 18px}.big{display:block;text-align:center;text-decoration:none;padding:15px;margin:10px 0}
.aviso{background:#fff3cd;color:#5c4400;padding:10px 12px;border-radius:10px;font-size:14px}.c{display:flex;align-items:center;gap:12px;background:${cor.ca};border:1px solid ${cor.bd};border-radius:14px;padding:10px;margin:10px 0;text-decoration:none;color:inherit}
.im{width:62px;height:62px;flex:none;border-radius:10px;background:${cor.bd} center/cover}.tx{flex:1;min-width:0;display:flex;flex-direction:column}.tx b{font-size:15px;line-height:1.3}.tx small{opacity:.7;margin-top:3px}.go{font-weight:700;color:${cor.ac};font-size:14px}footer{margin-top:24px;font-size:13px;opacity:.75}footer a{color:${cor.ac}}</style></head>
<body><main><div style="display:flex;align-items:center;gap:10px;font-weight:700;letter-spacing:.08em">${curso ? '<img src="/curso-logo.png" alt="" width="36" height="36" style="border-radius:9px">' : ''}${nome.toUpperCase()}</div>
<h1>Viu um post nosso?</h1><p>Escreva o código que aparece no post e abra o produto. Ou escolha na lista.</p>
${nao ? `<div class="aviso">O código ${esc(nao)} não existe. Confira as letras ou escolha na lista.</div>` : ''}
<form class="cod" onsubmit="var v=this.c.value.trim();if(v)location.href='/p/'+encodeURIComponent(v);return false"><input name="c" maxlength="6" placeholder="Ex.: K7H" autocomplete="off" autocapitalize="characters"><button>Abrir</button></form>
${curso ? `<a class="big" href="${SITE_CURSO}/cursos?aprender=1&utm_source=bio">Começar a aprender grátis</a>` : `<a class="big" href="/?falar=1&utm_source=bio">Falar com o nosso assistente</a>`}
${lista.map(card).join('')}
<a class="big" href="${base}${curso ? '/cursos' : '/'}?utm_source=bio" style="background:${cor.tx};color:${cor.bg}">Ver a loja completa</a>
<footer>${curso ? 'Dúvidas: <a href="/cursos?falar=1&utm_source=bio">fale com o nosso assistente</a>' : 'Fatos de noivos, vestes para noivas, roupas sob medida, ajustes de roupas sociais, uniformes de alta gama.'}</footer></main></body></html>`;
  return new Response(html, { headers: { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'public, max-age=300' } });
}
async function pagina(caminho, reqUrl) {
  const m = String(caminho || '').match(/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})\/?$/i);
  if (!m) return Response.redirect(`${SITE_CURSO}/cursos`, 302);
  const [p] = await produtos(`&id=eq.${m[1]}`);
  if (!p) return Response.redirect(`${SITE_CURSO}/cursos`, 302);
  const certo = urlProduto(p);
  if (new URL(certo).origin !== new URL(reqUrl).origin) return Response.redirect(certo, 301);
  if (!caminho.includes(slug(p.nome))) return Response.redirect(certo, 301);
  const digital = DIGITAIS.includes(p.tipo);
  const comprar = digital ? `${SITE_CURSO}/cursos?produto=${p.id}&utm_source=pesquisa` : `${SITE}/?produto=${p.id}&utm_source=pesquisa`;
  const desc = String(p.descricao || '').replace(/\s+/g, ' ').trim();
  const resumo = desc.slice(0, 155) + (desc.length > 155 ? '…' : '');
  const preco = precoAtual(p);
  const img = p.imagem_url && /\.(png|jpe?g|webp)(\?|$)/i.test(p.imagem_url) ? p.imagem_url : '';
  const outros = (await produtos(digital ? '&tipo=in.(ebook,combo)' : '')).filter(x => x.id !== p.id).slice(0, 8);
  const ld = { '@context': 'https://schema.org', '@type': 'Product', name: p.nome, description: desc.slice(0, 500), image: img || undefined, brand: { '@type': 'Brand', name: digital ? 'Plataforma Curso' : 'Dionuel' }, url: certo,
    offers: { '@type': 'Offer', price: preco, priceCurrency: p.moeda || 'AOA', availability: 'https://schema.org/InStock', url: comprar, seller: { '@type': 'Organization', name: digital ? 'Plataforma Curso' : 'Dionuel' } } };
  const html = `<!doctype html><html lang="pt"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(p.nome)} | ${digital ? 'Plataforma Curso' : 'Dionuel'}</title>
<meta name="description" content="${esc(resumo)}">
<link rel="canonical" href="${esc(certo)}">
<meta property="og:site_name" content="${digital ? 'Plataforma Curso' : 'Dionuel'}"><meta property="og:type" content="product"><meta property="og:title" content="${esc(p.nome)}"><meta property="og:description" content="${esc(resumo)}"><meta property="og:url" content="${esc(certo)}">${img ? `<meta property="og:image" content="${esc(img)}">` : ''}
<meta name="twitter:card" content="summary_large_image">
<script type="application/ld+json">${JSON.stringify(ld).replace(/</g, '\\u003c')}</script>
<link rel="icon" href="${digital ? '/curso-icon-192.png' : '/icon-192.png'}"><meta name="theme-color" content="${digital ? '#14284B' : '#1C1A17'}">
<style>body{margin:0;font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;background:${digital ? '#FBF9F2' : '#171412'};color:${digital ? '#14284B' : '#efe6da'};line-height:1.6}main{max-width:720px;margin:0 auto;padding:20px 16px 60px}a{color:${digital ? '#1B8A83' : '#d8b165'}}header a{text-decoration:none;font-weight:700;letter-spacing:.12em}img{width:100%;max-width:420px;border-radius:12px;display:block;margin:16px 0}h1{font-size:26px;line-height:1.25;margin:10px 0}.preco{font-size:24px;font-weight:800;color:${digital ? '#14284B' : '#d8b165'}}.btn{display:inline-block;background:${digital ? '#14284B' : '#b8935a'};color:${digital ? '#fff' : '#1a1a1a'};padding:14px 26px;border-radius:10px;font-weight:700;text-decoration:none;margin:14px 0}.desc{white-space:pre-wrap;color:${digital ? '#2d3f5c' : '#d6cabb'}}ul{padding-left:18px}footer{margin-top:40px;font-size:13px;color:${digital ? '#55657C' : '#a99c8c'}}</style></head>
<body><main><header>${digital ? `<a href="${SITE_CURSO}/cursos" style="display:flex;align-items:center;gap:10px"><img src="/curso-logo.png" alt="" width="36" height="36" style="margin:0;border-radius:9px;width:36px">PLATAFORMA CURSO</a>` : `<a href="${SITE}/">DIONUEL</a>`}</header>
<p style="font-size:13px;color:#a99c8c;margin:14px 0 0">${digital ? 'Livro digital · leitura imediata no telemóvel' : 'Dionuel Alfaiataria e Atelier de Costura · Ilha de Luanda'}</p>
<h1>${esc(p.nome)}</h1>
${img ? `<img src="${esc(img)}" alt="${esc(p.nome)}" width="420">` : ''}
<div class="preco">${esc(kz(preco))}</div>${p.codigo ? `<div style="font-size:14px;opacity:.8;margin-top:4px">Código ${esc(p.codigo)} · endereço curto: ${esc((digital ? SITE_CURSO : SITE).replace(/^https:\/\//, ""))}/p/${esc(p.codigo)}</div>` : ""}
<a class="btn" href="${esc(comprar)}">${digital ? 'Comprar já' : 'Pedir agora'}</a>
<div class="desc">${esc(desc)}</div>
<a class="btn" href="${esc(comprar)}">${digital ? 'Comprar já · ' + esc(kz(preco)) : 'Pedir agora'}</a>
${outros.length ? `<h2 style="font-size:18px;margin-top:30px">Também pode interessar</h2><ul>${outros.map(o => `<li><a href="${esc(urlProduto(o))}">${esc(o.nome)}</a></li>`).join('')}</ul>` : ''}
<footer>${digital ? `Plataforma Curso · Aprender · Aplicar · Crescer · <a href="/cursos?falar=1">Fale connosco</a>` : `Dionuel — Comércio Geral e Prestação de Serviços · Luanda, Angola · <a href="/?falar=1">Fale connosco</a><br>Especialidades do atelier: fatos de noivos, vestes para noivas, roupas sob medida, ajustes de roupas sociais, uniformes de alta gama.`}</footer>
</main></body></html>`;
  return new Response(html, { headers: { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'public, max-age=900' } });
}


// /cursos: a mesma aplicação, mas com identidade própria nas pesquisas e nas partilhas (título, ícone, imagem, descrição).
async function cursos(req) {
  const DESC = 'Cursos práticos no telemóvel com o professor ANNAN: aulas para ler, ouvir ou ver, prática real, provas e certificado. O nível básico de cada curso é grátis. Também livros, kits e ferramentas para aplicar.';
  const TITULO = 'Plataforma Curso — aprender, aplicar e crescer';
  const r = await fetch(new URL('/index.html', req.url), { headers: { 'Cache-Control': 'no-cache' } });
  if (!r.ok) throw new Error('index');
  let h = await r.text();
  const ld = { '@context': 'https://schema.org', '@type': 'Organization', name: 'Plataforma Curso', url: `${SITE_CURSO}/cursos`, logo: `${SITE_CURSO}/curso-logo.png`, slogan: 'Aprender · Aplicar · Crescer' };
  // a descrição da alfaiataria é substituída (antes ficava antes da do Curso e era a que o Google e o WhatsApp mostravam; auditoria da Fase 20)
  h = h.replace(/<title>[\s\S]*?<\/title>/, `<title>${TITULO}</title>`)
    .replace(/<meta name="description"[^>]*>\s*/gi, '')
    .replace(/<meta (property|name)="(og|twitter):[^"]*"[^>]*>\s*/gi, '')
    .replace('<link rel="manifest" href="manifest.json">', '<link rel="manifest" href="/manifest-curso.json">')
    .replace(/<link rel="icon"[^>]*>/, '<link rel="icon" href="/curso-icon-192.png" type="image/png">')
    .replace(/<link rel="apple-touch-icon"[^>]*>/, '<link rel="apple-touch-icon" href="/curso-icon-192.png">')
    .replace(/<meta name="theme-color"[^>]*>/, '<meta name="theme-color" content="#14284B">')
    .replace('id="splashMarca">DIONUEL<', 'id="splashMarca" style="color:#14284B;font-weight:700"><img src="/curso-logo.png" alt="" style="width:56px;height:56px;border-radius:14px;display:block;margin:0 auto 10px">PLATAFORMA CURSO<')
    .replace('<body>', '<body style="background:#FBF9F2">')
    .replace('</head>', `<meta name="description" content="${esc(DESC)}"><link rel="canonical" href="${SITE_CURSO}/cursos"><meta property="og:site_name" content="Plataforma Curso"><meta property="og:type" content="website"><meta property="og:title" content="${esc(TITULO)}"><meta property="og:description" content="${esc(DESC)}"><meta property="og:url" content="${SITE_CURSO}/cursos"><meta property="og:image" content="${SITE_CURSO}/curso-og.png"><meta name="twitter:card" content="summary_large_image"><script type="application/ld+json">${JSON.stringify(ld)}</script></head>`);
  return new Response(h, { headers: { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'public, max-age=300' } });
}

export default async (req) => {
  const u = new URL(req.url);
  try {
    // Cada domínio declara o seu próprio sitemap aos motores de pesquisa.
    if (u.pathname === '/robots.txt') {
      const sitemapSite = ehCurso(req.url) ? SITE_CURSO : SITE;
      const body = `User-agent: *\nAllow: /\nDisallow: /workflows-desativados/\nDisallow: /annan-drive/\n\nSitemap: ${sitemapSite}/sitemap.xml\n`;
      return new Response(body, { headers: { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'public, max-age=3600' } });
    }
    // a Plataforma Curso no endereço da Dionuel passa para o site próprio (com os parâmetros, ex.: ?aprender, ?produto, ?portefolio)
    if (/^\/cursos(\/.*)?$/.test(u.pathname) && !ehCurso(req.url)) return Response.redirect(`${SITE_CURSO}/cursos${u.search}`, 301);
    if (/^\/cursos(\/.*)?$/.test(u.pathname)) return await cursos(req);
    if (u.pathname.endsWith('/sitemap.xml') || u.searchParams.get('f') === 'sitemap') return await sitemap(ehCurso(req.url));
    if (/^\/(ver|bio|links)\/?$/.test(u.pathname)) return await bio(req);
    if (/^\/p\/[A-Za-z0-9]{2,6}\/?$/.test(u.pathname)) return await porCodigo(u.pathname.slice(3).replace(/\/$/, ''), req.url);
    const caminho = u.pathname.startsWith('/p/') ? u.pathname.slice(3) : (u.searchParams.get('p') || '');
    return await pagina(decodeURIComponent(caminho), req.url);
  } catch (_e) {
    return Response.redirect(ehCurso(req.url) ? `${SITE_CURSO}/cursos` : `${SITE}/`, 302);
  }
};

export const config = { path: ['/robots.txt', '/sitemap.xml', '/p/*', '/cursos', '/cursos/*', '/ver', '/bio', '/links'] };
