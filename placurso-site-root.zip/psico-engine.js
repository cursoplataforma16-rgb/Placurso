/* Motor de desafios da Plataforma Curso.
   Gera uma biblioteca local de milhares de variantes por combinação de parâmetros,
   evita repetição no dispositivo e só revela resultado após 10 respostas.
   O ANNAN pode substituir/adicionar famílias no futuro sem alterar a interface.
*/
(function(){
  'use strict';
  function init(){
    var old=document.querySelector('.pch-challenges');
    if(!old || old.dataset.psicoEngine==='v2') return;
    var host=old.parentNode;
    if(!host) return;
    var el=document.createElement('section');
    el.className='pch-challenges';
    /* A marca tem de ficar no elemento NOVO, que é o que fica na página. Antes ficava só no antigo (já removido):
       o observador via sempre um bloco sem marca, chamava init() outra vez, e isto repetia-se para sempre,
       congelando o telemóvel no ecrã de arranque (só em /cursos). */
    el.dataset.psicoEngine='v2';
    el.setAttribute('aria-labelledby','annanChallengeTitle');
    el.innerHTML=`
      <p class="pch-section-kicker">TREINE A MENTE</p>
      <h2 class="pch-h2" id="annanChallengeTitle">Desafios que mudam a cada ronda</h2>
      <p style="margin:9px 0 0;color:#55657C;font-size:14px;line-height:1.55">Raciocínio, atenção, memória, personalidade, aptidão, percentagens, proporções, séries figurativas e tomada de decisão. A ronda é aleatória. Praticar com regularidade ajuda a ganhar familiaridade, confiança e rapidez — sem substituir uma avaliação psicológica profissional.</p>
      <div class="pch-challenge-card" id="annanChallengeCard">
        <div class="pch-challenge-head"><span class="pch-tag" id="annanProgress">Pergunta 1 de 10</span><span class="pch-tag" id="annanType">Raciocínio</span><span class="pch-tag" id="annanTimer" aria-live="polite">2:30</span></div>
        <div class="pch-progress-track"><div class="pch-progress-fill" id="annanBar" style="width:0%"></div></div>
        <div id="annanTimeNote" style="margin:8px 0 0;color:#55657C;font-size:12px">Tempo desta questão: 2 min 30 s</div>
        <h3 class="pch-question" id="annanQuestion"></h3><div class="pch-choices" id="annanChoices"></div>
        <div class="pch-feedback" id="annanFeedback" hidden></div>
        <div class="pch-challenge-actions"><button type="button" id="annanAdvance" disabled>Avançar</button></div>
        <div class="pch-results" id="annanResults" hidden></div>
        <div class="pch-after3" id="annanLearn" hidden><h3>Quer melhorar nesta área?</h3><p id="annanLearnText">O ANNAN pode criar uma aula curta para treinar exactamente a habilidade em que está a errar mais.</p><button type="button" id="annanLearnBtn" style="min-height:44px;padding:0 16px;border:0;border-radius:10px;background:#14284B;color:#fff;font-weight:800;cursor:pointer">Aprender com ANNAN</button></div>
      </div>
      <div class="pch-challenge-card" id="annanCounterGame" style="margin-top:16px;border:1px solid #D9C8A7;background:linear-gradient(145deg,#fbf8f0,#f5efe2);box-shadow:0 14px 34px rgba(58,45,24,.10);overflow:hidden">
        <div style="display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap">
          <div><span class="pch-tag" style="background:#202A24;color:#F7EBD1">LINHA ORIENTAL</span><h3 style="margin:9px 0 0;color:#202A24;font-size:20px">Jogo do Contador</h3><p style="margin:5px 0 0;color:#6A6255;font-size:13px">Foco, percepção do tempo e disciplina.</p></div>
          <div style="width:132px;height:132px;border-radius:50%;padding:9px;background:conic-gradient(#A43D2F var(--counter-progress,0%),#E6DDCB 0);box-shadow:0 8px 22px rgba(70,50,25,.14)">
            <div style="width:100%;height:100%;border-radius:50%;background:#202A24;display:flex;align-items:center;justify-content:center;flex-direction:column;border:3px solid #D8C59F">
              <span id="annanCounterDisplay" aria-live="polite" style="font:800 26px/1.1 ui-monospace,SFMono-Regular,Menlo,monospace;color:#F7EBD1;letter-spacing:1px">00:00</span>
              <span style="font-size:9px;letter-spacing:1.5px;color:#CDBE9F;text-transform:uppercase">tempo</span>
            </div>
          </div>
        </div>
        <div style="height:1px;background:#E1D5BE;margin:16px 0"></div>
        <p style="margin:0 0 12px;color:#5F584C;font-size:14px;line-height:1.55">Escolha a meta. Observe o relógio. Treine a capacidade de acompanhar o tempo sem perder a atenção.</p>
        <div style="display:flex;gap:7px;flex-wrap:wrap;margin-bottom:12px">
          <button type="button" class="annan-counter-preset" data-min="1" style="min-height:36px;padding:0 12px;border:1px solid #CBBEAA;border-radius:999px;background:#fffaf0;color:#40392F;font-weight:800;cursor:pointer">1 min</button>
          <button type="button" class="annan-counter-preset" data-min="3" style="min-height:36px;padding:0 12px;border:1px solid #CBBEAA;border-radius:999px;background:#fffaf0;color:#40392F;font-weight:800;cursor:pointer">3 min</button>
          <button type="button" class="annan-counter-preset" data-min="5" style="min-height:36px;padding:0 12px;border:1px solid #CBBEAA;border-radius:999px;background:#fffaf0;color:#40392F;font-weight:800;cursor:pointer">5 min</button>
          <button type="button" class="annan-counter-preset" data-min="10" style="min-height:36px;padding:0 12px;border:1px solid #CBBEAA;border-radius:999px;background:#fffaf0;color:#40392F;font-weight:800;cursor:pointer">10 min</button>
        </div>
        <div style="display:flex;gap:9px;align-items:center;flex-wrap:wrap">
          <label for="annanCounterMinutes" style="font-weight:800;font-size:13px;color:#40392F">Meta</label>
          <input id="annanCounterMinutes" type="number" min="0.1" max="180" step="0.1" value="1" inputmode="decimal" aria-label="Minutos para parar o contador" style="width:92px;min-height:42px;padding:0 10px;border:1px solid #CBBEAA;border-radius:10px;background:#fffdf7;color:#202A24;font-weight:800">
          <span style="font-size:13px;color:#6A6255">minutos</span>
          <button type="button" id="annanCounterStart" style="min-height:42px;padding:0 16px;border:0;border-radius:10px;background:#A43D2F;color:#fff;font-weight:900;cursor:pointer;box-shadow:0 5px 12px rgba(164,61,47,.22)">▶ Iniciar</button>
          <button type="button" id="annanCounterReset" style="min-height:42px;padding:0 14px;border:1px solid #CBBEAA;border-radius:10px;background:#fffaf0;color:#40392F;font-weight:800;cursor:pointer">Reiniciar</button>
        </div>
        <div id="annanCounterStatus" aria-live="polite" style="margin-top:11px;color:#6A6255;font-size:12px">Pronto. A prática começa quando iniciar.</div>
        <div id="annanCounterCoach" style="margin-top:10px;padding:10px 12px;border-left:3px solid #A43D2F;background:rgba(255,255,255,.55);color:#4D463C;font-size:12px;line-height:1.5">Orientador: não procure velocidade; procure consistência. Quem pratica reconhece melhor o próprio ritmo.</div>
      </div>
      <div class="pch-challenge-card" id="annanChessGame" style="margin-top:16px;border:1px solid #D9C8A7;background:linear-gradient(145deg,#fbf8f0,#f4eee2);box-shadow:0 14px 34px rgba(58,45,24,.10)">
        <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;flex-wrap:wrap">
          <div><span class="pch-tag" style="background:#202A24;color:#F7EBD1">LINHA ORIENTAL · ESTRATÉGIA</span><h3 style="margin:9px 0 0;color:#202A24;font-size:20px">Xadrez com Orientador ANNAN</h3><p id="annanChessCoach" style="margin:6px 0 0;color:#6A6255;font-size:13px;line-height:1.5">Escolha a jogada que melhor prepara a posição. O objetivo é treinar pensamento antes da ação.</p></div>
          <span id="annanChessScore" class="pch-tag">0/0</span>
        </div>
        <div style="display:grid;grid-template-columns:minmax(220px,340px) 1fr;gap:18px;align-items:center;margin-top:14px">
          <div id="annanChessBoard" aria-label="Tabuleiro de xadrez de treino" style="width:100%;max-width:340px;aspect-ratio:1;border:7px solid #202A24;border-radius:8px;overflow:hidden;box-shadow:0 10px 22px rgba(42,32,20,.16)"></div>
          <div><div id="annanChessPrompt" style="font-weight:900;color:#202A24;font-size:15px;line-height:1.45;margin-bottom:10px"></div><div id="annanChessMoves" style="display:grid;gap:8px"></div><div id="annanChessFeedback" aria-live="polite" style="margin-top:10px;padding:10px 12px;border-left:3px solid #A43D2F;background:rgba(255,255,255,.55);color:#4D463C;font-size:12px;line-height:1.5"></div><button type="button" id="annanChessNext" style="display:none;margin-top:10px;min-height:42px;padding:0 15px;border:0;border-radius:10px;background:#202A24;color:#F7EBD1;font-weight:900;cursor:pointer">Próxima jogada</button></div>
        </div>
        <div id="annanChessAdvice" style="margin-top:14px;padding:11px 13px;border-radius:10px;background:#EEE6D6;color:#514A40;font-size:12px;line-height:1.55">Orientador: pense no centro, segurança do rei, desenvolvimento e material. Uma boa jogada não precisa ser a mais rápida.</div>
        <div id="annanChessCourse" hidden style="margin-top:12px;padding:13px;border-radius:10px;background:#202A24;color:#F7EBD1"><strong>O seu resultado mostra espaço para prática.</strong><p style="margin:7px 0;color:#E6DDCB;font-size:13px;line-height:1.5">Treinar xadrez pode ajudar a exercitar planeamento, análise de alternativas e tomada de decisão. Um curso estruturado dá exercícios progressivos, feedback e uma rotina de prática.</p><button type="button" id="annanChessCourseBtn" style="min-height:42px;padding:0 15px;border:0;border-radius:10px;background:#A43D2F;color:#fff;font-weight:900;cursor:pointer">Ver curso recomendado</button></div>
      </div>`;
    host.replaceChild(el,old);
    start(el);
  }
  function esc(s){return String(s).replace(/[&<>\"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
  function shuffle(a,r){for(var i=a.length-1;i>0;i--){var j=Math.floor(r()* (i+1)),t=a[i];a[i]=a[j];a[j]=t;}return a;}
  function rng(seed){var x=(seed>>>0)||1;return function(){x^=x<<13;x^=x>>>17;x^=x<<5;return (x>>>0)/4294967296;};}
  function gcd(a,b){while(b){var t=a%b;a=b;b=t;}return Math.abs(a);}
  function unique(arr){var m={},o=[];arr.forEach(function(x){var k=x.id;if(!m[k]){m[k]=1;o.push(x);}});return o;}
  function chessPuzzles(r){
    return shuffle([
      {prompt:'No início da partida, qual jogada ajuda mais a disputar o centro?',moves:['1. e4','1. a4','1. h4','1. Rh3'],answer:0,why:'e4 ocupa o centro e abre linhas para o desenvolvimento. O princípio é criar opções, não atacar por impulso.',pieces:{'e2':'♙','d2':'♙','f2':'♙','g2':'♙','h2':'♙','a2':'♙','b2':'♙','c2':'♙','e7':'♟','d7':'♟','f7':'♟','g7':'♟','h7':'♟','a7':'♟','b7':'♟','c7':'♟','a1':'♖','h1':'♖','c1':'♗','f1':'♗','b1':'♘','g1':'♘','d1':'♕','e1':'♔','a8':'♜','h8':'♜','c8':'♝','f8':'♝','b8':'♞','g8':'♞','d8':'♛','e8':'♚'}},
      {prompt:'Depois de 1.e4 e5, qual desenvolvimento é mais natural?',moves:['2. Nf3','2. Rh3','2. a4','2. Qh5'],answer:0,why:'Nf3 desenvolve uma peça, controla o centro e prepara decisões futuras. Desenvolver antes de procurar ataques prematuros é uma base sólida.',pieces:{'e4':'♙','e5':'♟','d2':'♙','f2':'♙','g2':'♙','h2':'♙','a2':'♙','b2':'♙','c2':'♙','d7':'♟','f7':'♟','g7':'♟','h7':'♟','a7':'♟','b7':'♟','c7':'♟','a1':'♖','h1':'♖','c1':'♗','f1':'♗','b1':'♘','g1':'♘','d1':'♕','e1':'♔','a8':'♜','h8':'♜','c8':'♝','f8':'♝','b8':'♞','g8':'♞','d8':'♛','e8':'♚'}},
      {prompt:'O rei está no centro e já é possível rocar. Qual ideia deve ser priorizada?',moves:['3. O-O','3. h3','3. a3','3. Qg4'],answer:0,why:'O roque melhora a segurança do rei e liga as torres. Segurança primeiro, ataque depois.',pieces:{'e1':'♔','h1':'♖','a1':'♖','f1':'♗','c1':'♗','g1':'♘','b1':'♘','d1':'♕','e2':'♙','d2':'♙','f2':'♙','g2':'♙','h2':'♙','a2':'♙','b2':'♙','c2':'♙','e8':'♚','a8':'♜','h8':'♜','d8':'♛','c8':'♝','f8':'♝','b8':'♞','g8':'♞','a7':'♟','b7':'♟','c7':'♟','d7':'♟','f7':'♟','g7':'♟','h7':'♟'}},
      {prompt:'Tem duas capturas possíveis. O que deve verificar antes de jogar?',moves:['Se a peça fica segura depois da captura','Capturar sempre a peça de maior valor','Jogar imediatamente para ganhar tempo','Ignorar a posição do rei'],answer:0,why:'A melhor decisão considera a consequência da jogada. Verifique a resposta do adversário antes de assumir que ganhou material.',pieces:{'e4':'♙','d5':'♟','c3':'♘','f6':'♞','g2':'♙','g7':'♟','e1':'♔','e8':'♚','a1':'♖','h1':'♖','a8':'♜','h8':'♜','d1':'♕','d8':'♛','c1':'♗','f1':'♗','c8':'♝','f8':'♝'}},
      {prompt:'Quando não encontra uma jogada clara, qual método é mais útil?',moves:['Avaliar ameaças, candidatos e consequências','Jogar a primeira opção que aparece','Mudar de plano sem analisar','Acelerar para não perder tempo'],answer:0,why:'Criar candidatos e comparar consequências reduz decisões impulsivas. O treino serve para transformar este processo em hábito.',pieces:{'e1':'♔','g1':'♘','f1':'♗','d1':'♕','a1':'♖','h1':'♖','e8':'♚','g8':'♞','f8':'♝','d8':'♛','a8':'♜','h8':'♜','e4':'♙','d4':'♙','c3':'♘','f3':'♗','e5':'♟','d5':'♟','c6':'♞','f6':'♝'}}
    ],r);
  }
  function makePool(seed){
    var r=rng(seed), q=[];
    function add(type,text,opts,answer,explain){q.push({id:type+'-'+text+'-'+opts.join('|'),type:type,text:text,opts:opts,answer:answer,explain:explain});}
    for(var n=0;n<160;n++){
      var a=2+Math.floor(r()*28), d=1+Math.floor(r()*9), len=4+Math.floor(r()*3), vals=[],i;
      for(i=0;i<len;i++) vals.push(a+i*d);
      var miss=1+Math.floor(r()*(len-2)), correct=String(vals[miss]); var shown=vals.slice();shown[miss]='?';
      var opts=shuffle([correct,String(Number(correct)+d),String(Number(correct)-d),String(Number(correct)+2*d)],r);
      add('sequencia',`Qual número completa a sequência ${shown.join(', ')}?`,opts,opts.indexOf(correct),'A sequência aumenta sempre de '+d+'.');
    }
    for(n=0;n<140;n++){
      var x=3+Math.floor(r()*25), y=2+Math.floor(r()*14), op=n%3, ans=op===0?x*y:op===1?x+y:x*y+y;
      var text=op===0?`Se ${x} caixas têm ${y} itens cada, quantos itens existem?`:op===1?`Quanto é ${x} + ${y}?`:`Se cada grupo tem ${x} itens e há ${y} grupos, acrescentando ${y} itens, qual o total?`;
      var os=shuffle([String(ans),String(ans+2),String(Math.max(0,ans-2)),String(ans+y)],r);
      add('numerico',text,os,os.indexOf(String(ans)),'Calcule a operação apresentada e confira as unidades.');
    }
    var words=[['maçã','banana','laranja','cadeira'],['azul','verde','amarelo','janela'],['cão','gato','cavalo','martelo'],['segunda','terça','quarta','janeiro'],['ferro','cobre','ouro','papel']];
    words.forEach(function(set){var odd=set[3];add('classificacao',`Qual palavra pertence a uma categoria diferente: ${set.join(', ')}?`,shuffle(set.slice(),r),set.indexOf(odd),'Três itens pertencem à mesma categoria; um não.');});
    for(n=0;n<80;n++){var base=['ABC','CDE','EFG','GHI','JKL','LMN','NOP','PQR'][Math.floor(r()*8)], idx=Math.floor(r()*3), letters=base.split(''), target=letters[idx]; letters[idx]='?';var choices=shuffle([target,String.fromCharCode(target.charCodeAt(0)+1),String.fromCharCode(target.charCodeAt(0)-1),String.fromCharCode(target.charCodeAt(0)+2)],r);add('atencao',`Complete a sequência de letras: ${letters.join(' ')}.`,choices,choices.indexOf(target),'Cada letra avança uma posição no alfabeto.');}
    for(n=0;n<90;n++){var p=2+Math.floor(r()*8), t=2+Math.floor(r()*6), total=p+t, correct=p>t?'A maioria escolheu A':'A maioria escolheu B';var opts=shuffle(['A maioria escolheu A','A maioria escolheu B','As duas opções empataram','Não é possível saber'],r);add('logica',`Num grupo, ${p} pessoas escolhem A e ${t} escolhem B. Qual conclusão é correcta?`,opts,opts.indexOf(correct),'Compare directamente as duas quantidades.');}
    var profiles=[['Quando recebe uma tarefa nova, você prefere:',['começar logo e ajustar no caminho','analisar antes e depois começar','pedir exemplos primeiro','dividir em pequenas etapas']],['Sob pressão de tempo, você tende a:',['priorizar o essencial','rever tudo duas vezes','pedir mais tempo','seguir a primeira ideia']],['Num trabalho de equipa, você costuma:',['organizar prioridades','gerar ideias','verificar detalhes','facilitar acordos']]];
    profiles.forEach(function(p){var os=p[1].slice();add('perfil',p[0],os,0,'Não há resposta certa: a escolha descreve uma preferência de comportamento.');});
    for(n=0;n<110;n++){var good=['verificar os dados antes de decidir','dividir o problema em etapas','comparar duas alternativas','testar uma solução pequena primeiro'][Math.floor(r()*4)];var os=shuffle([good,'escolher ao acaso','ignorar os dados','fazer tudo de uma vez'],r);add('desempenho',`Você tem pouco tempo e uma decisão importante. Qual atitude tende a reduzir erros?`,os,os.indexOf(good),'Estruturar a decisão e verificar informação relevante tende a reduzir erros.');}
    for(n=0;n<80;n++){var red=2+Math.floor(r()*7), blue=1+Math.floor(r()*6), bag=red+blue, goodp=`${red}/${bag}`;var os=shuffle([goodp,`${blue}/${bag}`,`${red}/${bag-1}`,`${blue}/${bag+1}`],r);add('probabilidade',`Uma caixa tem ${red} peças vermelhas e ${blue} azuis. Qual é a probabilidade de tirar uma vermelha numa escolha?`,os,os.indexOf(goodp),'Probabilidade = casos favoráveis ÷ casos possíveis.');}
    for(n=0;n<80;n++){var s=1+Math.floor(r()*6), mult=2+Math.floor(r()*4), ans=s*mult;var os=shuffle([String(ans),String(ans+s),String(ans-mult),String(ans+mult)],r);add('memoria',`Memorize ${s} × ${mult}. Sem calcular com pressa: qual é o resultado?`,os,os.indexOf(String(ans)),'Multiplique o primeiro número pelo segundo.');}
    for(n=0;n<80;n++){var a1=1+Math.floor(r()*9), b1=1+Math.floor(r()*9), c1=1+Math.floor(r()*9), good=a1+b1+c1;var os=shuffle([String(good),String(good+1),String(good-1),String(a1*b1+c1)],r);add('velocidade',`Sem perder atenção: ${a1} + ${b1} + ${c1} = ?`,os,os.indexOf(String(good)),'Some os três valores na ordem apresentada.');}
    for(n=0;n<80;n++){var statements=[['Todos os livros são objetos. Este item é um livro.','Este item é um objeto.'],['Alguns estudantes treinam xadrez. Ana é estudante.','Não é possível concluir que Ana treina xadrez.'],['Se chover, a rua pode ficar molhada. Choveu.','A rua pode ficar molhada.']];var z=statements[n%statements.length], os=shuffle([z[1],'A conclusão é necessariamente falsa.','Não há relação possível.','O contrário é sempre verdadeiro.'],r);add('deducao',z[0]+' Qual conclusão é mais adequada?',os,os.indexOf(z[1]),'A conclusão deve respeitar exactamente as informações dadas, sem acrescentar suposições.');}

    /* Tipos observados no teste de referência: percentagens/concentração,
       séries figurativas/rotação e problemas de proporção. */
    for(n=0;n<90;n++){
      var basePct=20+Math.floor(r()*30), liters1=20+Math.floor(r()*60), liters2=60+Math.floor(r()*100);
      var pct2=basePct+10+Math.floor(r()*25);
      var totalLiters=liters1+liters2, exact=(liters1*basePct+liters2*pct2)/totalLiters;
      var correctPct=(Math.round(exact*100)/100).toFixed(2).replace('.',',')+'%';
      var pctOpts=shuffle([correctPct,
        (Math.round((exact+5)*100)/100).toFixed(2).replace('.',',')+'%',
        (Math.round((exact-5)*100)/100).toFixed(2).replace('.',',')+'%',
        (Math.round((basePct+pct2)/2*100)/100).toFixed(2).replace('.',',')+'%'],r);
      add('percentagem',`Misturam-se ${liters1} litros de solução a ${basePct}% com ${liters2} litros a ${pct2}%. Qual é a concentração final?`,pctOpts,pctOpts.indexOf(correctPct),'Calcule a quantidade de matéria ativa de cada solução e divida pelo volume total.');
    }
    for(n=0;n<80;n++){
      var total=4+Math.floor(r()*5), known=1+Math.floor(r()*(total-1)), unit=2+Math.floor(r()*6);
      var target=unit*total, knownVal=unit*known, missing=target-knownVal;
      var propOpts=shuffle([String(missing),String(missing+unit),String(Math.max(1,missing-unit)),String(missing+knownVal)],r);
      add('proporcao',`Se ${known} unidades correspondem a ${knownVal}, quantas correspondem a ${total} unidades?`,propOpts,propOpts.indexOf(String(missing)),'Determine primeiro o valor de uma unidade e depois multiplique pela quantidade pedida.');
    }
    var rotations=[
      ['▲','▶','▼','◀'],['◀','▲','▶','▼'],['●○','○●','●○','○●'],['└','┌','┐','┘']
    ];
    for(n=0;n<80;n++){
      var seq=rotations[n%rotations.length].slice(), missingIndex=1+Math.floor(r()*2);
      var shown=seq.slice(); var correctFig=shown[missingIndex]; shown[missingIndex]='?';
      var expected=(missingIndex+1)%seq.length;
      var correctRot=seq[expected];
      var rotOpts=shuffle([correctRot,seq[(expected+1)%seq.length],seq[(expected+3)%seq.length],seq[(expected+2)%seq.length]],r);
      add('serie-rotacao',`Complete a série de figuras por rotação: ${shown.join('  ')}`,rotOpts,rotOpts.indexOf(correctRot),'A figura gira uma posição de cada vez no mesmo sentido.');
    }
    return unique(q);
  }
  function start(root){
    var seed=Number(localStorage.getItem('annan_psico_seed')||0)+1;localStorage.setItem('annan_psico_seed',String(seed));
    var pool=makePool(seed*2654435761>>>0), used=[];try{used=JSON.parse(localStorage.getItem('annan_psico_seen')||'[]');}catch(_e){used=[];}var seen=new Set(used);pool=pool.filter(function(x){return !seen.has(x.id);});if(pool.length<10){localStorage.removeItem('annan_psico_seen');seen.clear();pool=makePool(seed*2654435761>>>0);}
    pool=shuffle(pool,rng((seed^0x9e3779b9)>>>0));var round=pool.slice(0,10), index=0, selected=null, correct=0, errors=0, types={};
    var qEl=root.querySelector('#annanQuestion'), cEl=root.querySelector('#annanChoices'), pEl=root.querySelector('#annanProgress'), tEl=root.querySelector('#annanType'), timerEl=root.querySelector('#annanTimer'), timeNote=root.querySelector('#annanTimeNote'), bar=root.querySelector('#annanBar'), adv=root.querySelector('#annanAdvance'), feed=root.querySelector('#annanFeedback'), res=root.querySelector('#annanResults'), learn=root.querySelector('#annanLearn'), learnBtn=root.querySelector('#annanLearnBtn');
    var chessBoard=root.querySelector('#annanChessBoard'), chessPrompt=root.querySelector('#annanChessPrompt'), chessMoves=root.querySelector('#annanChessMoves'), chessFeedback=root.querySelector('#annanChessFeedback'), chessNext=root.querySelector('#annanChessNext'), chessScore=root.querySelector('#annanChessScore'), chessAdvice=root.querySelector('#annanChessAdvice'), chessCourse=root.querySelector('#annanChessCourse'), chessCourseBtn=root.querySelector('#annanChessCourseBtn'), chessCoach=root.querySelector('#annanChessCoach');
    var questionTimes=[150,137,123,110,97,83,70,57,43,30], timerId=null, deadline=0, answered=false;
    var chessRound=chessPuzzles(rng((seed*1103515245+12345)>>>0)), chessIndex=0, chessCorrect=0, chessAnswered=false;
    function formatTime(sec){sec=Math.max(0,Math.ceil(sec));return Math.floor(sec/60)+':'+String(sec%60).padStart(2,'0');}
    function stopQuestionTimer(){if(timerId){clearInterval(timerId);timerId=null;}}
    function submitCurrent(){if(answered)return;answered=true;stopQuestionTimer();if(selected===null){selected=-1;}var item=round[index];var is=selected===item.answer;types[item.type]=(types[item.type]||0)+(is?1:0);if(is)correct++;else errors++;seen.add(item.id);localStorage.setItem('annan_psico_seen',JSON.stringify(Array.from(seen).slice(-1500)));index++;if(index<10){render();if(errors>=3)learn.hidden=false;}else finish();}
    function render(){stopQuestionTimer();var item=round[index], limit=questionTimes[index];selected=null;answered=false;adv.disabled=true;feed.hidden=true;pEl.textContent=`Pergunta ${index+1} de 10`;tEl.textContent=({percentagem:'Percentagens',proporcao:'Proporções', 'serie-rotacao':'Série figurativa',sequencia:'Sequência numérica',numerico:'Cálculo',classificacao:'Classificação',atencao:'Atenção',logica:'Lógica',perfil:'Perfil',desempenho:'Tomada de decisão',probabilidade:'Probabilidade',memoria:'Memória',velocidade:'Velocidade',deducao:'Dedução'}[item.type]||item.type);bar.style.width=(index*10)+'%';qEl.textContent=item.text;cEl.innerHTML='';timeNote.textContent='Tempo desta questão: '+formatTime(limit).replace(':',' min ')+' s';deadline=Date.now()+limit*1000;timerEl.textContent=formatTime(limit);item.opts.forEach(function(o,i){var b=document.createElement('button');b.type='button';b.className='pch-choice';b.textContent=o;b.addEventListener('click',function(){if(answered)return;cEl.querySelectorAll('.pch-choice').forEach(function(x){x.classList.remove('selecionada');});b.classList.add('selecionada');selected=i;adv.disabled=false;});cEl.appendChild(b);});timerId=setInterval(function(){var left=Math.max(0,(deadline-Date.now())/1000);timerEl.textContent=formatTime(left);if(left<=0){submitCurrent();}},250);}
    adv.addEventListener('click',function(){if(selected===null || answered)return;submitCurrent();});
    /* Jogo do contador: cronómetro independente com meta configurável em minutos. */
    (function(){
      var counter=root.querySelector('#annanCounterDisplay'), input=root.querySelector('#annanCounterMinutes'), startBtn=root.querySelector('#annanCounterStart'), resetBtn=root.querySelector('#annanCounterReset'), status=root.querySelector('#annanCounterStatus'), coach=root.querySelector('#annanCounterCoach'), presets=root.querySelectorAll('.annan-counter-preset');
      var counterId=null,counterStart=0,counterTarget=0;
      function fmt(ms){var s=Math.floor(ms/1000);return String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0');}
      function paint(ms){var pct=counterTarget?Math.min(100,(ms/counterTarget)*100):0;counter.parentElement.parentElement.style.setProperty('--counter-progress',pct+'%');counter.textContent=fmt(ms);}
      function reset(){if(counterId)clearInterval(counterId);counterId=null;counterStart=0;counterTarget=0;paint(0);status.textContent='Pronto. A prática começa quando iniciar.';coach.textContent='Orientador: não procure velocidade; procure consistência. Quem pratica reconhece melhor o próprio ritmo.';startBtn.disabled=false;}
      presets.forEach(function(btn){btn.addEventListener('click',function(){if(counterId)return;input.value=btn.dataset.min;status.textContent='Meta definida para '+btn.dataset.min+' minuto(s).';});});
      startBtn.addEventListener('click',function(){
        var minutes=Number(input.value);
        if(!isFinite(minutes)||minutes<=0){status.textContent='Indique um número de minutos maior que zero.';input.focus();return;}
        if(counterId)clearInterval(counterId);
        counterStart=Date.now();counterTarget=minutes*60000;paint(0);startBtn.disabled=true;status.textContent='Cronómetro em andamento…';coach.textContent='Orientador: mantenha a atenção no ritmo. A constância é uma habilidade treinável.';
        counterId=setInterval(function(){var elapsed=Date.now()-counterStart;paint(elapsed);if(elapsed>=counterTarget){clearInterval(counterId);counterId=null;paint(counterTarget);status.textContent='Meta atingida — excelente. Reinicie para treinar novamente.';coach.textContent='Orientador: repetir o exercício ajuda a tornar a percepção do tempo mais estável e consciente.';startBtn.disabled=false;}},100);
      });
      resetBtn.addEventListener('click',reset);
    }());
    (function(){
      function renderBoard(p){
        chessBoard.innerHTML='';
        var files=['a','b','c','d','e','f','g','h'];
        for(var row=8;row>=1;row--){for(var fi=0;fi<8;fi++){var sq=files[fi]+row,cell=document.createElement('div');cell.textContent=p.pieces[sq]||'';cell.setAttribute('data-square',sq);cell.style.cssText='display:flex;align-items:center;justify-content:center;font-size:clamp(23px,6vw,40px);line-height:1;aspect-ratio:1;'+(((row+fi)%2===0)?'background:#E8D8B7;color:#202A24;':'background:#6F776A;color:#F7EBD1;');chessBoard.appendChild(cell);}}
      }
      function showPuzzle(){
        var p=chessRound[chessIndex];chessAnswered=false;chessPrompt.textContent=p.prompt;chessFeedback.textContent='Orientador: compare as opções antes de escolher. Pergunte: o que melhora a posição depois desta jogada?';chessNext.style.display='none';chessScore.textContent=chessCorrect+'/'+chessIndex;chessCoach.textContent='Jogada '+(chessIndex+1)+' de '+chessRound.length+' · pense antes de mover.';renderBoard(p);chessMoves.innerHTML='';
        p.moves.forEach(function(move,i){var b=document.createElement('button');b.type='button';b.textContent=move;b.style.cssText='min-height:42px;padding:0 12px;border:1px solid #CBBEAA;border-radius:9px;background:#fffaf0;color:#40392F;font-weight:800;text-align:left;cursor:pointer';b.addEventListener('click',function(){if(chessAnswered)return;chessAnswered=true;var ok=i===p.answer;if(ok)chessCorrect++;chessScore.textContent=chessCorrect+'/'+(chessIndex+1);b.style.background=ok?'#DDE8D8':'#F1D9D4';b.style.borderColor=ok?'#78946E':'#B96A5B';chessMoves.querySelectorAll('button').forEach(function(x){x.disabled=true;});chessFeedback.innerHTML=ok?'<strong>Boa leitura.</strong> '+esc(p.why):'<strong>Boa tentativa.</strong> '+esc(p.why)+' Use o erro como informação: a prática serve para reconhecer o padrão na próxima vez.';chessNext.style.display='inline-flex';if(chessIndex===chessRound.length-1){chessNext.textContent='Ver desempenho';} });chessMoves.appendChild(b);});
      }
      chessNext.addEventListener('click',function(){if(!chessAnswered)return;if(chessIndex<chessRound.length-1){chessIndex++;showPuzzle();return;}var pct=Math.round(chessCorrect/chessRound.length*100);chessAdvice.textContent='Desempenho: '+chessCorrect+'/'+chessRound.length+' ('+pct+'%). '+(pct>=60?'Continue a praticar: consistência nasce da repetição consciente.':'Este resultado indica uma área boa para treino. Um curso estruturado pode acelerar a aprendizagem com exercícios progressivos, feedback e estratégia.');chessCourse.hidden=pct>=60;chessNext.style.display='none';if(pct<60){chessCourseBtn.onclick=function(){location.href='/cursos?aprender=1&tema=xadrez%20e%20estrategia';};}});
      showPuzzle();
    }());
    learnBtn.addEventListener('click',function(){var topic=Object.keys(types).sort(function(a,b){return types[a]-types[b];})[0]||'raciocínio';try{if(typeof window.irParaAprender==='function')window.irParaAprender('Quero uma aula curta para melhorar '+topic+' em testes e desafios psicotécnicos.');else location.href='/cursos?aprender=1&tema='+encodeURIComponent(topic);}catch(_e){location.href='/cursos?aprender=1&tema='+encodeURIComponent(topic);}});
    function finish(){stopQuestionTimer();bar.style.width='100%';pEl.textContent='Ronda concluída — 10 de 10';qEl.textContent='Ronda concluída';cEl.innerHTML='';adv.disabled=true;feed.hidden=true;res.hidden=false;var pct=Math.round(correct*10);var strengths=Object.keys(types).sort(function(a,b){return types[b]-types[a];}).slice(0,2);var weak=Object.keys(types).sort(function(a,b){return types[a]-types[b];})[0]||'raciocínio';var labels={percentagem:'percentagens',proporcao:'proporções','serie-rotacao':'séries figurativas',sequencia:'sequências',numerico:'cálculo',classificacao:'classificação',atencao:'atenção',logica:'lógica',perfil:'autoconhecimento',desempenho:'tomada de decisão',probabilidade:'probabilidade',memoria:'memória',velocidade:'velocidade',deducao:'dedução'};var weakLabel=labels[weak]||weak;var recommendation=pct<70?`<div style="margin-top:12px;padding:14px;border-radius:11px;background:#202A24;color:#F7EBD1"><strong>ANNAN identificou uma área para praticar: ${esc(weakLabel)}.</strong><p style="margin:7px 0;color:#E6DDCB;font-size:13px;line-height:1.55">Não é um diagnóstico. É um sinal de treino. Um curso estruturado pode dar exercícios progressivos, explicações, repetição e feedback — vantagens práticas para ganhar confiança e responder com mais clareza sob pressão.</p><button type="button" id="annanPsychCourseBtn" style="min-height:42px;padding:0 15px;border:0;border-radius:10px;background:#A43D2F;color:#fff;font-weight:900;cursor:pointer">Treinar ${esc(weakLabel)}</button></div>`:'<div style="margin-top:12px;padding:12px;border-left:3px solid #78946E;background:#F1F5ED;color:#43513D;font-size:13px;line-height:1.5"><strong>Boa base.</strong> Continue a praticar para transformar acertos em consistência. Preparação reduz a surpresa e aumenta a confiança na execução.</div>';res.innerHTML=`<strong>${correct}/10 acertos (${pct}%)</strong><p style="margin:8px 0">As explicações aparecem agora. O resultado é apenas treino e não constitui diagnóstico psicológico.</p><p style="margin:8px 0"><b>Pontos fortes nesta ronda:</b> ${esc(strengths.map(function(x){return labels[x]||x;}).join(', ')||'diversos')}</p>`+recommendation+round.map(function(x,i){return `<div class="pch-review"><details><summary>${i+1}. ${esc(labels[x.type]||x.type)} — ver lógica</summary><p>${esc(x.explain)}</p></details></div>`;}).join('');var note=document.createElement('p');note.style.cssText='margin:12px 0 0;color:#55657C;font-size:12px';note.textContent='Nova ronda: o motor muda os números, estruturas, contextos e tipos para evitar repetições.';res.appendChild(note);var psychBtn=root.querySelector('#annanPsychCourseBtn');if(psychBtn)psychBtn.onclick=function(){location.href='/cursos?aprender=1&tema='+encodeURIComponent(weakLabel);};}
    render();
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
  /* Quando a página inicial é desenhada mais tarde, liga o motor uma vez. Com travão: no máximo 20 ligações por visita,
     para que um erro futuro nunca volte a congelar a página num ciclo infinito. */
  var ligacoes=0;
  new MutationObserver(function(){
    if(ligacoes>=20 || location.pathname!=='/cursos') return;
    if(document.querySelector('.pch-challenges') && !document.querySelector('.pch-challenges[data-psico-engine="v2"]')){ ligacoes++; init(); }
  }).observe(document.documentElement,{childList:true,subtree:true});
})();
